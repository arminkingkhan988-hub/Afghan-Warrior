# AFGHAN WARRIOR – افغان جنګیالی
**Complete Offline 3D Third-Person Tactical Military Action Game for Android (Godot 4.3+)**

## Overview
AFGHAN WARRIOR is an offline 3D third-person shooter built for Android devices using Godot Engine 4's Mobile Forward+ / GL Compatibility rendering pipeline. Set across fictionalized Afghan-inspired mountain valleys, mud-brick villages, and fortified outposts, the game supports **English (LTR)** and **Pashto (RTL — پښتو)** with full local save persistence.

## Implemented Features
- **Third-Person Camera & Soldier Controller**: Smooth `SpringArm3D` camera collision, over-the-shoulder aim zoom, walking, running, sprinting, jumping, crouching, cover stance, health, armor, weapon inventory, and procedural character hit/death reactions.
- **Weapons System (5 Firearms + Frag Grenade)**: Assault Rifle (`Khyber-47`), Sniper Rifle (`Pamir Longbow M24`), Shotgun (`Helmand Breacher 12G`), Pistol (`Kabul 9mm`), Submachine Gun (`Balkh PDW`), and `HE-Fragmentation` grenades, plus object-pooled muzzle flashes, bullet tracers, and weapon/ammo pickups.
- **Enemy AI**: `NavigationAgent3D` patrol paths, line-of-sight + gunfire sound awareness, cover-seeking, burst attacks, reload cycles, search/retreat behaviors, and Recruit / Veteran / Elite difficulty scaling.
- **Game Modes**:
  - **Story Mode**: 10 structured missions; **Missions 1–3** are fully playable with briefings, wave/objective triggers, rewards, and progression unlocks; Missions 4–10 are structured in `data/missions/missions.json` for rapid expansion.
  - **Free Battle Mode**: Select map (Afghan Village, Mountain Valley, Military Outpost), enemy difficulty, enemy count, starting weapon, time of day (Day / Dusk / Night), and weather (Clear / Dust / Rain), with instant restart.
- **Three Playable Maps**:
  1. `map_afghan_village.tscn` — Mud-brick houses, arches, narrow streets, checkpoint, trees, rock perimeter.
  2. `map_mountain_valley.tscn` — Rocky canyon ridges, river plane, stone/wood bridge, patrol cliffs.
  3. `map_military_outpost.tscn` — Watchtowers, concrete barriers, storage sheds, vehicle park.
- **Vehicle Foundation**: Enterable/exitable Military Jeep and Transport Truck (`scripts/vehicles/vehicle_base.gd`) with basic driving physics and collision.
- **Android Mobile Touch Controls**: Left virtual thumbstick + right camera drag pad + Fire, Aim, Jump, Crouch, Reload, Switch Weapon, Grenade, Sprint, Interact, and Pause buttons.
- **Graphics Presets (LOW / MEDIUM / HIGH)** & **Audio Buses (Music / SFX / Environment)** saved offline in `user://save_data.json`.

## Asset Disclosure (Transparency)
- **3D Models**: Character, enemy, weapon, vehicle, and architecture meshes in the `.tscn` scenes are constructed from modular procedural Godot 3D primitives and multi-part `Node3D` assemblies (flagged clearly as modular procedural meshes—no external copyrighted assets). Replace with custom `.glb` rigs in `assets/models/` for production art polish.
- **Textures & Audio**: All `.png` textures in `assets/textures/` and `.wav` audio files in `assets/audio/` are 100% original, procedurally synthesized assets generated locally.
- **Real-Device Verification**: Android APK compilation and multi-touch thermal testing must be performed on physical Android hardware with Android SDK/Godot Export Templates installed (cannot be executed inside a headless Linux container without Android NDK/APK signing).
