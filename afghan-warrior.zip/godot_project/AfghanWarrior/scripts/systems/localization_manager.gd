extends Node

signal language_changed(lang_code: String, is_rtl: bool)

var current_language: String = "en"
var translations: Dictionary = {}

func _ready() -> void:
	_load_all_translations()
	var saved_lang: String = str(SaveManager.data.get("language", "en"))
	set_language(saved_lang)

func _load_all_translations() -> void:
	for lang in ["en", "ps"]:
		var path := "res://data/translations/%s.json" % lang
		if FileAccess.file_exists(path):
			var file := FileAccess.open(path, FileAccess.READ)
			if file:
				var parsed: Variant = JSON.parse_string(file.get_as_text())
				file.close()
				if typeof(parsed) == TYPE_DICTIONARY:
					translations[lang] = parsed

func set_language(lang_code: String) -> void:
	if not translations.has(lang_code):
		lang_code = "en"
	current_language = lang_code
	SaveManager.data["language"] = lang_code
	SaveManager.save_game()
	TranslationServer.set_locale(lang_code)
	var is_rtl := (lang_code == "ps")
	var tree := get_tree()
	if tree and tree.root:
		var dir := Control.LAYOUT_DIRECTION_RTL if is_rtl else Control.LAYOUT_DIRECTION_LTR
		tree.root.propagate_notification(NOTIFICATION_TRANSLATION_CHANGED)
		for child in tree.root.get_children():
			if child is Control:
				child.layout_direction = dir
	language_changed.emit(current_language, is_rtl)

func is_rtl() -> bool:
	return current_language == "ps"

func tr_key(key: String) -> String:
	var dict: Dictionary = translations.get(current_language, {})
	if dict.has(key):
		return str(dict[key])
	var fallback: Dictionary = translations.get("en", {})
	return str(fallback.get(key, key))
