extends Node

var music_player: AudioStreamPlayer
var env_player: AudioStreamPlayer
var sfx_pool: Array[AudioStreamPlayer] = []
var pool_index: int = 0

var music_volume: float = 0.75
var sfx_volume: float = 0.85
var env_volume: float = 0.70

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	music_player = AudioStreamPlayer.new()
	add_child(music_player)
	env_player = AudioStreamPlayer.new()
	add_child(env_player)
	for i in range(12):
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_pool.append(p)
	apply_volumes(
		float(SaveManager.data.get("music_volume", 0.75)),
		float(SaveManager.data.get("sfx_volume", 0.85)),
		float(SaveManager.data.get("env_volume", 0.70))
	)

func apply_volumes(music: float, sfx: float, env: float) -> void:
	music_volume = clampf(music, 0.0, 1.0)
	sfx_volume = clampf(sfx, 0.0, 1.0)
	env_volume = clampf(env, 0.0, 1.0)
	music_player.volume_db = linear_to_db(maxf(0.001, music_volume))
	env_player.volume_db = linear_to_db(maxf(0.001, env_volume))

func play_music(path: String) -> void:
	if not ResourceLoader.exists(path):
		return
	var stream := load(path) as AudioStream
	if stream:
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		music_player.stream = stream
		music_player.play()

func play_environment(path: String) -> void:
	if not ResourceLoader.exists(path):
		return
	var stream := load(path) as AudioStream
	if stream:
		if stream is AudioStreamWAV:
			stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		env_player.stream = stream
		env_player.play()

func stop_environment() -> void:
	env_player.stop()

func play_sfx(path: String, pitch_scale: float = 1.0) -> void:
	if not ResourceLoader.exists(path):
		return
	var stream := load(path) as AudioStream
	if not stream:
		return
	var p := sfx_pool[pool_index]
	pool_index = (pool_index + 1) % sfx_pool.size()
	p.stream = stream
	p.pitch_scale = pitch_scale
	p.volume_db = linear_to_db(maxf(0.001, sfx_volume))
	p.play()
