extends Node

enum GraphicsQuality { LOW = 0, MEDIUM = 1, HIGH = 2 }

var current_quality: int = GraphicsQuality.MEDIUM
var camera_sensitivity: float = 1.0
var aim_sensitivity: float = 0.65
var control_sensitivity: float = 1.0

func _ready() -> void:
	load_and_apply()

func load_and_apply() -> void:
	current_quality = int(SaveManager.data.get("graphics_quality", GraphicsQuality.MEDIUM))
	camera_sensitivity = float(SaveManager.data.get("camera_sensitivity", 1.0))
	aim_sensitivity = float(SaveManager.data.get("aim_sensitivity", 0.65))
	control_sensitivity = float(SaveManager.data.get("control_sensitivity", 1.0))
	apply_graphics_preset(current_quality)
	apply_screen_mode(bool(SaveManager.data.get("fullscreen", true)))

func apply_graphics_preset(quality: int) -> void:
	current_quality = clampi(quality, 0, 2)
	SaveManager.data["graphics_quality"] = current_quality
	var vp := get_viewport()
	if vp:
		match current_quality:
			GraphicsQuality.LOW:
				vp.scaling_3d_scale = 0.70
				vp.msaa_3d = Viewport.MSAA_DISABLED
				RenderingServer.directional_shadow_atlas_set_size(1024, false)
			GraphicsQuality.MEDIUM:
				vp.scaling_3d_scale = 0.85
				vp.msaa_3d = Viewport.MSAA_2X
				RenderingServer.directional_shadow_atlas_set_size(2048, true)
			GraphicsQuality.HIGH:
				vp.scaling_3d_scale = 1.0
				vp.msaa_3d = Viewport.MSAA_4X
				RenderingServer.directional_shadow_atlas_set_size(4096, true)
	SaveManager.save_game()

func apply_screen_mode(fullscreen: bool) -> void:
	SaveManager.data["fullscreen"] = fullscreen
	if OS.has_feature("android") or OS.has_feature("mobile"):
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED)
	SaveManager.save_game()
