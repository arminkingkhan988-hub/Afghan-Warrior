extends Node

enum GameMode { STORY, FREE_BATTLE }

var active_mode: int = GameMode.STORY
var active_mission_id: int = 1
var missions_cache: Array = []
var weapons_cache: Array = []

var free_battle_config: Dictionary = {
	"map_id": "village",
	"map_scene": "res://scenes/maps/map_afghan_village.tscn",
	"difficulty": "veteran",
	"enemy_count": 6,
	"starting_weapon": "khyber_47",
	"time_of_day": "day",
	"weather": "clear"
}

func _ready() -> void:
	_load_missions()
	_load_weapons()

func _load_missions() -> void:
	var path := "res://data/missions/missions.json"
	if FileAccess.file_exists(path):
		var file := FileAccess.open(path, FileAccess.READ)
		if file:
			var parsed: Variant = JSON.parse_string(file.get_as_text())
			file.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				missions_cache = parsed.get("missions", [])

func _load_weapons() -> void:
	var path := "res://data/weapons/weapons.json"
	if FileAccess.file_exists(path):
		var file := FileAccess.open(path, FileAccess.READ)
		if file:
			var parsed: Variant = JSON.parse_string(file.get_as_text())
			file.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				weapons_cache = parsed.get("weapons", [])

func get_mission_by_id(mission_id: int) -> Dictionary:
	for m in missions_cache:
		if int(m.get("id", 0)) == mission_id:
			return m
	return {}

func start_story_mission(mission_id: int) -> void:
	active_mode = GameMode.STORY
	active_mission_id = mission_id
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main/main.tscn")

func start_free_battle(config: Dictionary) -> void:
	active_mode = GameMode.FREE_BATTLE
	free_battle_config = config.duplicate()
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main/main.tscn")

func return_to_main_menu() -> void:
	get_tree().paused = false
	AudioManager.stop_environment()
	get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")
