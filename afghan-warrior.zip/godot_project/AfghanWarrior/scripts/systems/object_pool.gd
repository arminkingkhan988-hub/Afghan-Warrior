extends Node
class_name ObjectPool

var pooled_tracers: Array[MeshInstance3D] = []
var tracer_index: int = 0

func _ready() -> void:
	for i in range(24):
		var mesh := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.04, 0.04, 1.4)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(1.0, 0.85, 0.35)
		mat.emission_enabled = true
		mat.emission = Color(1.0, 0.72, 0.2)
		mat.emission_energy_multiplier = 3.0
		box.material = mat
		mesh.mesh = box
		mesh.visible = false
		add_child(mesh)
		pooled_tracers.append(mesh)

func spawn_tracer(from_pos: Vector3, to_pos: Vector3) -> void:
	var tracer := pooled_tracers[tracer_index]
	tracer_index = (tracer_index + 1) % pooled_tracers.size()
	var mid := (from_pos + to_pos) * 0.5
	tracer.global_position = mid
	if from_pos.distance_to(to_pos) > 0.1:
		tracer.look_at(to_pos, Vector3.UP)
	tracer.visible = true
	var tween := create_tween()
	tween.tween_interval(0.06)
	tween.tween_callback(func(): tracer.visible = false)
