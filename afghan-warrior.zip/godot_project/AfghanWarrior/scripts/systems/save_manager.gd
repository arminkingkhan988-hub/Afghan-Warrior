extends Node
class_name SaveManagerClass

const SAVE_PATH := "user://afghan_warrior_save.json"

var data: Dictionary = {
	"language": "en",
	"graphics_quality": 1, # 0=LOW, 1=MEDIUM, 2=HIGH
	"music_volume": 0.75,
	"sfx_volume": 0.85,
	"env_volume": 0.70,
	"camera_sensitivity": 1.0,
	"aim_sensitivity": 0.65,
	"control_sensitivity": 1.0,
	"fullscreen": true,
	"unlocked_mission": 1,
	"completed_missions": [],
	"total_score": 0,
	"unlocked_weapons": ["khyber_47", "pamir_m24", "helmand_12g", "kabul_9mm", "balkh_pdw"]
}

func _ready() -> void:
	load_game()

func save_game() -> void:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data, "\t"))
		file.close()

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		save_game()
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file:
		var text := file.get_as_text()
		file.close()
		var parsed: Variant = JSON.parse_string(text)
		if typeof(parsed) == TYPE_DICTIONARY:
			for key in parsed.keys():
				data[key] = parsed[key]

func mark_mission_completed(mission_id: int, reward_points: int, next_mission: int) -> void:
	var completed: Array = data.get("completed_missions", [])
	if not completed.has(mission_id):
		completed.append(mission_id)
		data["completed_missions"] = completed
	data["total_score"] = int(data.get("total_score", 0)) + reward_points
	if next_mission > int(data.get("unlocked_mission", 1)):
		data["unlocked_mission"] = next_mission
	save_game()
