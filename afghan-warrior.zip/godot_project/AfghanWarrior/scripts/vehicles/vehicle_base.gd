extends CharacterBody3D
class_name MilitaryVehicle

@export var vehicle_name: String = "Military Jeep"
@export var max_speed: float = 15.0
@export var turn_speed: float = 2.0

var driver: PlayerController = null
var gravity: float = 15.0

func _ready() -> void:
	add_to_group("vehicles")

func interact(player: PlayerController) -> void:
	if driver == null:
		driver = player
		player.active_vehicle = self
		player.visible = false
		AudioManager.play_sfx("res://assets/audio/vehicle_engine.wav")

func exit_vehicle(player: PlayerController) -> void:
	driver = null
	player.global_position = global_position + global_transform.basis.x * 2.4

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	if driver:
		var throttle := Input.get_action_strength("move_forward") - Input.get_action_strength("move_backward")
		var steer := Input.get_action_strength("move_left") - Input.get_action_strength("move_right")
		if absf(throttle) > 0.05:
			rotation.y += steer * turn_speed * delta * signf(throttle)
		var forward := -global_transform.basis.z
		velocity.x = forward.x * throttle * max_speed
		velocity.z = forward.z * throttle * max_speed
	else:
		velocity.x = lerpf(velocity.x, 0.0, delta * 4.0)
		velocity.z = lerpf(velocity.z, 0.0, delta * 4.0)
	move_and_slide()
