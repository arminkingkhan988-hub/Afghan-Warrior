extends Control

@onready var mission_list: VBoxContainer = $Scroll/MissionList

func _ready() -> void:
	var unlocked := int(SaveManager.data.get("unlocked_mission", 1))
	for m in GameManager.missions_cache:
		var mid := int(m["id"])
		var btn := Button.new()
		var title := str(m.get("title_ps" if LocalizationManager.is_rtl() else "title_en"))
		var is_playable := bool(m.get("implemented", false))
		btn.text = "%s %s" % [title, "" if is_playable else "(Briefing Blueprint)"]
		btn.disabled = mid > unlocked
		btn.pressed.connect(func():
			if is_playable:
				GameManager.start_story_mission(mid)
		)
		mission_list.add_child(btn)

func _on_back_pressed() -> void:
	GameManager.return_to_main_menu()
