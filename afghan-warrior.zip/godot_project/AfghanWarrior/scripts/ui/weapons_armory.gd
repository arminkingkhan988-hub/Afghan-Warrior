extends Control

@onready var weapon_list: VBoxContainer = $Scroll/WeaponList

func _ready() -> void:
	for w in GameManager.weapons_cache:
		var lbl := Label.new()
		var name_str := str(w.get("name_ps" if LocalizationManager.is_rtl() else "name_en"))
		lbl.text = "%s | DMG: %s | MAG: %s | RANGE: %sm" % [name_str, str(w["damage"]), str(w["mag_size"]), str(w["range"])]
		weapon_list.add_child(lbl)

func _on_back_pressed() -> void:
	GameManager.return_to_main_menu()
