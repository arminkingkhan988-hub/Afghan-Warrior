extends Control

@onready var title_label: Label = $Panel/VBox/TitleLabel
@onready var quality_option: OptionButton = $Panel/VBox/QualityRow/QualityOption
@onready var music_slider: HSlider = $Panel/VBox/MusicRow/MusicSlider
@onready var sfx_slider: HSlider = $Panel/VBox/SfxRow/SfxSlider
@onready var env_slider: HSlider = $Panel/VBox/EnvRow/EnvSlider
@onready var cam_slider: HSlider = $Panel/VBox/CamRow/CamSlider
@onready var lang_btn: Button = $Panel/VBox/LanguageBtn
@onready var save_btn: Button = $Panel/VBox/Actions/SaveBtn
@onready var back_btn: Button = $Panel/VBox/Actions/BackBtn

func _ready() -> void:
	quality_option.clear()
	quality_option.add_item(LocalizationManager.tr_key("QUALITY_LOW"), 0)
	quality_option.add_item(LocalizationManager.tr_key("QUALITY_MEDIUM"), 1)
	quality_option.add_item(LocalizationManager.tr_key("QUALITY_HIGH"), 2)
	quality_option.selected = SettingsManager.current_quality
	music_slider.value = AudioManager.music_volume
	sfx_slider.value = AudioManager.sfx_volume
	env_slider.value = AudioManager.env_volume
	cam_slider.value = SettingsManager.camera_sensitivity
	_refresh_text()

func _refresh_text() -> void:
	title_label.text = LocalizationManager.tr_key("SETTINGS_TITLE")
	lang_btn.text = LocalizationManager.tr_key("LANG_PASHTO" if not LocalizationManager.is_rtl() else "LANG_ENGLISH")
	save_btn.text = LocalizationManager.tr_key("SETTINGS_SAVE")
	back_btn.text = LocalizationManager.tr_key("MENU_BACK")

func _on_language_pressed() -> void:
	LocalizationManager.set_language("ps" if LocalizationManager.current_language == "en" else "en")
	_refresh_text()

func _on_save_pressed() -> void:
	SettingsManager.apply_graphics_preset(quality_option.selected)
	SettingsManager.camera_sensitivity = cam_slider.value
	SaveManager.data["camera_sensitivity"] = cam_slider.value
	SaveManager.data["music_volume"] = music_slider.value
	SaveManager.data["sfx_volume"] = sfx_slider.value
	SaveManager.data["env_volume"] = env_slider.value
	AudioManager.apply_volumes(music_slider.value, sfx_slider.value, env_slider.value)
	SaveManager.save_game()
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")

func _on_back_pressed() -> void:
	GameManager.return_to_main_menu()
