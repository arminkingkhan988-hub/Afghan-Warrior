extends Control

@onready var title_label: Label = $Margin/VBox/Header/TitleLabel
@onready var subtitle_label: Label = $Margin/VBox/Header/SubtitleLabel
@onready var story_btn: Button = $Margin/VBox/Buttons/StoryBtn
@onready var free_btn: Button = $Margin/VBox/Buttons/FreeBattleBtn
@onready var settings_btn: Button = $Margin/VBox/Buttons/SettingsBtn
@onready var lang_btn: Button = $Margin/VBox/Buttons/LanguageBtn
@onready var about_btn: Button = $Margin/VBox/Buttons/AboutBtn
@onready var exit_btn: Button = $Margin/VBox/Buttons/ExitBtn
@onready var info_label: Label = $Margin/VBox/InfoPanel/InfoLabel

func _ready() -> void:
	AudioManager.play_music("res://assets/audio/menu_theme.wav")
	LocalizationManager.language_changed.connect(func(_l, _r): _refresh_labels())
	_refresh_labels()

func _refresh_labels() -> void:
	title_label.text = LocalizationManager.tr_key("APP_TITLE")
	subtitle_label.text = LocalizationManager.tr_key("APP_SUBTITLE")
	story_btn.text = LocalizationManager.tr_key("MENU_STORY")
	free_btn.text = LocalizationManager.tr_key("MENU_FREE_BATTLE")
	settings_btn.text = LocalizationManager.tr_key("MENU_SETTINGS")
	lang_btn.text = "%s: %s" % [LocalizationManager.tr_key("MENU_LANGUAGE"), LocalizationManager.tr_key("LANG_PASHTO" if not LocalizationManager.is_rtl() else "LANG_ENGLISH")]
	about_btn.text = LocalizationManager.tr_key("MENU_ABOUT")
	exit_btn.text = LocalizationManager.tr_key("MENU_EXIT")
	info_label.text = LocalizationManager.tr_key("ABOUT_TEXT")

func _on_story_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	var unlocked := int(SaveManager.data.get("unlocked_mission", 1))
	GameManager.start_story_mission(mini(unlocked, 3))

func _on_missions_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	get_tree().change_scene_to_file("res://scenes/menus/mission_select.tscn")

func _on_free_battle_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	get_tree().change_scene_to_file("res://scenes/menus/free_battle_menu.tscn")

func _on_weapons_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	get_tree().change_scene_to_file("res://scenes/menus/weapons_armory.tscn")

func _on_settings_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	get_tree().change_scene_to_file("res://scenes/ui/settings_menu.tscn")

func _on_language_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	LocalizationManager.set_language("ps" if LocalizationManager.current_language == "en" else "en")

func _on_about_pressed() -> void:
	AudioManager.play_sfx("res://assets/audio/ui_click.wav")
	info_label.text = LocalizationManager.tr_key("ABOUT_TEXT")

func _on_exit_pressed() -> void:
	get_tree().quit()
