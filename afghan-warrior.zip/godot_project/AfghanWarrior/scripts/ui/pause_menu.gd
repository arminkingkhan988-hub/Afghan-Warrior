extends Control

@onready var title_label: Label = $Panel/VBox/TitleLabel
@onready var resume_btn: Button = $Panel/VBox/ResumeBtn
@onready var restart_btn: Button = $Panel/VBox/RestartBtn
@onready var menu_btn: Button = $Panel/VBox/MenuBtn

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	_refresh_text()

func _refresh_text() -> void:
	if title_label: title_label.text = LocalizationManager.tr_key("PAUSE_TITLE")
	if resume_btn: resume_btn.text = LocalizationManager.tr_key("PAUSE_RESUME")
	if restart_btn: restart_btn.text = LocalizationManager.tr_key("PAUSE_RESTART")
	if menu_btn: menu_btn.text = LocalizationManager.tr_key("PAUSE_MAIN_MENU")

func show_result(victory: bool) -> void:
	visible = true
	get_tree().paused = true
	if title_label:
		title_label.text = LocalizationManager.tr_key("RESULT_VICTORY" if victory else "RESULT_DEFEAT")
	if resume_btn:
		resume_btn.visible = false

func _on_resume_pressed() -> void:
	visible = false
	get_tree().paused = false

func _on_restart_pressed() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_menu_pressed() -> void:
	GameManager.return_to_main_menu()
