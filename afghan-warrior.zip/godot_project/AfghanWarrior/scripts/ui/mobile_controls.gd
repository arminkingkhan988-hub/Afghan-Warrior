extends Control

var player: PlayerController
var joystick_center: Vector2 = Vector2.ZERO
var joystick_touch_id: int = -1
var look_touch_id: int = -1
var joystick_radius: float = 68.0

@onready var joystick_bg: Control = $JoystickArea/JoystickBG
@onready var joystick_knob: Control = $JoystickArea/JoystickBG/Knob

func bind_player(p: PlayerController) -> void:
	player = p

func _ready() -> void:
	if joystick_bg:
		joystick_center = joystick_bg.size * 0.5

func _input(event: InputEvent) -> void:
	if not player:
		return
	if event is InputEventScreenTouch:
		var pos: Vector2 = event.position
		if event.pressed:
			if pos.x < get_viewport_rect().size.x * 0.42 and joystick_touch_id == -1:
				joystick_touch_id = event.index
			elif pos.x >= get_viewport_rect().size.x * 0.42 and look_touch_id == -1:
				look_touch_id = event.index
		else:
			if event.index == joystick_touch_id:
				joystick_touch_id = -1
				player.set_mobile_move(Vector2.ZERO)
				if joystick_knob:
					joystick_knob.position = joystick_center - joystick_knob.size * 0.5
			elif event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch_id and joystick_bg:
			var local_pos := joystick_bg.get_local_mouse_position()
			var offset := local_pos - joystick_center
			if offset.length() > joystick_radius:
				offset = offset.normalized() * joystick_radius
			if joystick_knob:
				joystick_knob.position = joystick_center + offset - joystick_knob.size * 0.5
			player.set_mobile_move(offset / joystick_radius)
		elif event.index == look_touch_id:
			player.set_mobile_look(event.relative.x, event.relative.y)

func _on_fire_down() -> void:
	if player: player.mobile_firing = true

func _on_fire_up() -> void:
	if player: player.mobile_firing = false

func _on_aim_pressed() -> void:
	if player: player.mobile_aiming = not player.mobile_aiming

func _on_jump_pressed() -> void:
	if player and player.is_on_floor(): player.velocity.y = player.jump_velocity

func _on_crouch_pressed() -> void:
	if player: player.toggle_crouch()

func _on_reload_pressed() -> void:
	if player: player.weapon_manager.start_reload()

func _on_switch_pressed() -> void:
	if player: player.weapon_manager.switch_next_weapon()

func _on_interact_pressed() -> void:
	if player: player.try_interact()

func _on_grenade_pressed() -> void:
	if player: player.throw_grenade()

func _on_pause_pressed() -> void:
	get_tree().paused = true
	var pause := get_parent().get_node_or_null("PauseMenu")
	if pause:
		pause.visible = true
