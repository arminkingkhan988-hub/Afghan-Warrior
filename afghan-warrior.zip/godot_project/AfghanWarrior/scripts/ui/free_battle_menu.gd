extends Control

@onready var map_option: OptionButton = $Panel/VBox/MapOption
@onready var diff_option: OptionButton = $Panel/VBox/DiffOption
@onready var weapon_option: OptionButton = $Panel/VBox/WeaponOption
@onready var time_option: OptionButton = $Panel/VBox/TimeOption
@onready var weather_option: OptionButton = $Panel/VBox/WeatherOption
@onready var enemy_spin: SpinBox = $Panel/VBox/EnemySpin

var map_scenes := [
	"res://scenes/maps/map_afghan_village.tscn",
	"res://scenes/maps/map_mountain_valley.tscn",
	"res://scenes/maps/map_military_outpost.tscn"
]
var diffs := ["recruit", "veteran", "elite"]
var weapon_ids := ["khyber_47", "pamir_m24", "helmand_12g", "kabul_9mm", "balkh_pdw"]
var times := ["day", "dusk", "night"]
var weathers := ["clear", "dust", "rain"]

func _ready() -> void:
	map_option.add_item(LocalizationManager.tr_key("MAP_VILLAGE"))
	map_option.add_item(LocalizationManager.tr_key("MAP_VALLEY"))
	map_option.add_item(LocalizationManager.tr_key("MAP_OUTPOST"))
	diff_option.add_item(LocalizationManager.tr_key("DIFF_RECRUIT"))
	diff_option.add_item(LocalizationManager.tr_key("DIFF_VETERAN"))
	diff_option.add_item(LocalizationManager.tr_key("DIFF_ELITE"))
	diff_option.selected = 1
	for w in GameManager.weapons_cache:
		weapon_option.add_item(str(w.get("name_ps" if LocalizationManager.is_rtl() else "name_en")))
	time_option.add_item(LocalizationManager.tr_key("TIME_DAY"))
	time_option.add_item(LocalizationManager.tr_key("TIME_DUSK"))
	time_option.add_item(LocalizationManager.tr_key("TIME_NIGHT"))
	weather_option.add_item(LocalizationManager.tr_key("WEATHER_CLEAR"))
	weather_option.add_item(LocalizationManager.tr_key("WEATHER_DUST"))
	weather_option.add_item(LocalizationManager.tr_key("WEATHER_RAIN"))

func _on_deploy_pressed() -> void:
	GameManager.start_free_battle({
		"map_scene": map_scenes[map_option.selected],
		"difficulty": diffs[diff_option.selected],
		"enemy_count": int(enemy_spin.value),
		"starting_weapon": weapon_ids[maxi(0, weapon_option.selected)],
		"time_of_day": times[time_option.selected],
		"weather": weathers[weather_option.selected]
	})

func _on_back_pressed() -> void:
	GameManager.return_to_main_menu()
