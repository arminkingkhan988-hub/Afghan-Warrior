extends Control

@onready var health_bar: ProgressBar = $TopLeft/HealthBar
@onready var armor_bar: ProgressBar = $TopLeft/ArmorBar
@onready var ammo_label: Label = $BottomRight/AmmoLabel
@onready var weapon_label: Label = $BottomRight/WeaponLabel
@onready var objective_label: Label = $TopCenter/ObjectiveLabel
@onready var enemy_label: Label = $TopCenter/EnemyLabel

func bind_player(player: PlayerController) -> void:
	player.health_changed.connect(_on_health_changed)
	player.weapon_manager.ammo_changed.connect(_on_ammo_changed)
	_on_health_changed(player.health, player.armor)
	player.weapon_manager.emit_ammo_update()

func _on_health_changed(hp: int, arm: int) -> void:
	if health_bar: health_bar.value = hp
	if armor_bar: armor_bar.value = arm

func _on_ammo_changed(mag: int, reserve: int, w_name: String, reloading: bool) -> void:
	if weapon_label: weapon_label.text = w_name
	if ammo_label:
		ammo_label.text = LocalizationManager.tr_key("HUD_RELOADING") if reloading else "%d / %d" % [mag, reserve]

func set_objective(text: String) -> void:
	if objective_label:
		objective_label.text = "%s: %s" % [LocalizationManager.tr_key("HUD_OBJECTIVE"), text]

func set_enemy_count(count: int) -> void:
	if enemy_label:
		enemy_label.text = "%s: %d" % [LocalizationManager.tr_key("HUD_ENEMIES"), count]
