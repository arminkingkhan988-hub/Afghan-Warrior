extends CharacterBody3D
class_name EnemyAI

signal died(enemy: EnemyAI)

enum State { PATROL, ALERT, ENGAGE, TAKE_COVER, RELOAD, RETREAT, DEAD }

@export var max_health: int = 85
@export var move_speed: float = 3.8
@export var detection_range: float = 28.0
@export var attack_range: float = 22.0
@export var damage_per_shot: int = 9

var health: int = 85
var state: int = State.PATROL
var mag_ammo: int = 20
var fire_timer: float = 0.0
var reload_timer: float = 0.0
var state_timer: float = 0.0
var patrol_points: Array[Vector3] = []
var patrol_index: int = 0
var player_ref: Node3D = null
var gravity: float = 15.0

@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var model_root: Node3D = $EnemyModel

func _ready() -> void:
	add_to_group("enemies")
	add_to_group("damageable")
	health = max_health
	var base := global_position
	patrol_points = [
		base + Vector3(6, 0, 0),
		base + Vector3(6, 0, 6),
		base + Vector3(-6, 0, 4)
	]

func configure_difficulty(diff: String) -> void:
	match diff:
		"recruit":
			max_health = 65
			damage_per_shot = 6
			move_speed = 3.2
		"elite":
			max_health = 120
			damage_per_shot = 14
			move_speed = 4.6
		_:
			max_health = 85
			damage_per_shot = 9
			move_speed = 3.8
	health = max_health

func alert_to_sound(sound_pos: Vector3) -> void:
	if state == State.DEAD:
		return
	if global_position.distance_to(sound_pos) <= detection_range * 1.4:
		if nav_agent:
			nav_agent.target_position = sound_pos
		if state == State.PATROL:
			state = State.ALERT

func _physics_process(delta: float) -> void:
	if state == State.DEAD:
		return
	if not is_on_floor():
		velocity.y -= gravity * delta

	if not player_ref:
		var players := get_tree().get_nodes_in_group("player")
		if not players.is_empty():
			player_ref = players[0]

	var dist_to_player := 999.0
	var can_see_player := false
	if player_ref and is_instance_valid(player_ref):
		dist_to_player = global_position.distance_to(player_ref.global_position)
		if dist_to_player <= detection_range:
			can_see_player = _has_line_of_sight(player_ref.global_position + Vector3(0, 1.2, 0))

	match state:
		State.PATROL:
			if can_see_player:
				state = State.ENGAGE
			else:
				_move_along_patrol(delta)
		State.ALERT:
			if can_see_player:
				state = State.ENGAGE
			else:
				_move_toward_target(delta)
				state_timer += delta
				if state_timer > 5.0:
					state_timer = 0.0
					state = State.PATROL
		State.ENGAGE:
			if not can_see_player:
				state = State.ALERT
				if player_ref:
					nav_agent.target_position = player_ref.global_position
			elif health < max_health * 0.25:
				state = State.RETREAT
			else:
				_engage_player(delta, dist_to_player)
		State.TAKE_COVER:
			state_timer += delta
			_move_toward_target(delta)
			if state_timer > 2.2:
				state_timer = 0.0
				state = State.ENGAGE
		State.RELOAD:
			reload_timer -= delta
			if reload_timer <= 0.0:
				mag_ammo = 20
				state = State.ENGAGE
		State.RETREAT:
			if player_ref:
				var away := (global_position - player_ref.global_position).normalized()
				nav_agent.target_position = global_position + away * 10.0
				_move_toward_target(delta)
			state_timer += delta
			if state_timer > 3.0:
				state_timer = 0.0
				state = State.TAKE_COVER

	move_and_slide()

func _has_line_of_sight(target_pos: Vector3) -> bool:
	var space := get_world_3d().direct_space_state
	var eye := global_position + Vector3(0, 1.5, 0)
	var query := PhysicsRayQueryParameters3D.create(eye, target_pos)
	query.exclude = [get_rid()]
	var res := space.intersect_ray(query)
	if res.is_empty():
		return true
	var col: Object = res["collider"]
	return col != null and col.is_in_group("player")

func _move_along_patrol(_delta: float) -> void:
	if patrol_points.is_empty():
		return
	var target := patrol_points[patrol_index]
	if global_position.distance_to(target) < 1.5:
		patrol_index = (patrol_index + 1) % patrol_points.size()
		target = patrol_points[patrol_index]
	nav_agent.target_position = target
	_move_toward_target(_delta)

func _move_toward_target(delta: float) -> void:
	if nav_agent.is_navigation_finished():
		velocity.x = 0.0
		velocity.z = 0.0
		return
	var next_pos := nav_agent.get_next_path_position()
	var dir := (next_pos - global_position)
	dir.y = 0.0
	if dir.length() > 0.05:
		dir = dir.normalized()
		velocity.x = dir.x * move_speed
		velocity.z = dir.z * move_speed
		if model_root:
			model_root.rotation.y = lerp_angle(model_root.rotation.y, atan2(dir.x, dir.z), delta * 8.0)

func _engage_player(delta: float, dist: float) -> void:
	if not player_ref:
		return
	var dir := (player_ref.global_position - global_position)
	dir.y = 0.0
	if dir.length() > 0.01 and model_root:
		model_root.rotation.y = lerp_angle(model_root.rotation.y, atan2(dir.x, dir.z), delta * 10.0)

	if dist > attack_range * 0.65:
		nav_agent.target_position = player_ref.global_position
		_move_toward_target(delta)
	else:
		velocity.x = 0.0
		velocity.z = 0.0

	if mag_ammo <= 0:
		state = State.RELOAD
		reload_timer = 1.9
		return

	fire_timer -= delta
	if fire_timer <= 0.0 and dist <= attack_range:
		fire_timer = randf_range(0.38, 0.75)
		mag_ammo -= 1
		AudioManager.play_sfx("res://assets/audio/rifle_shot.wav", 0.92)
		if randf() < 0.42 and player_ref.has_method("apply_damage"):
			player_ref.apply_damage(damage_per_shot, dir.normalized())

func apply_damage(amount: int, _dir: Vector3 = Vector3.ZERO) -> void:
	if state == State.DEAD:
		return
	health -= amount
	if state == State.PATROL:
		state = State.ENGAGE
	if health <= 0:
		state = State.DEAD
		velocity = Vector3.ZERO
		if model_root:
			model_root.rotation_degrees.x = 85.0
		$CollisionShape3D.disabled = true
		died.emit(self)
		get_tree().create_timer(4.0).timeout.connect(queue_free)
