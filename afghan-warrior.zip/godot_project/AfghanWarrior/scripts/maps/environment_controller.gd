extends Node3D
class_name EnvironmentController

@export var sun_light: DirectionalLight3D
@export var world_env: WorldEnvironment

func apply_conditions(time_of_day: String, weather: String) -> void:
	if sun_light:
		match time_of_day:
			"dusk":
				sun_light.rotation_degrees = Vector3(-16, 42, 0)
				sun_light.light_color = Color(1.0, 0.72, 0.45)
				sun_light.light_energy = 1.15
			"night":
				sun_light.rotation_degrees = Vector3(-55, 25, 0)
				sun_light.light_color = Color(0.55, 0.68, 0.95)
				sun_light.light_energy = 0.35
			_:
				sun_light.rotation_degrees = Vector3(-48, 35, 0)
				sun_light.light_color = Color(1.0, 0.95, 0.86)
				sun_light.light_energy = 1.5

	if world_env and world_env.environment:
		var env := world_env.environment
		env.fog_enabled = true
		match weather:
			"dust":
				env.fog_light_color = Color(0.76, 0.66, 0.50)
				env.fog_density = 0.018
				AudioManager.play_environment("res://assets/audio/wind_ambient.wav")
			"rain":
				env.fog_light_color = Color(0.45, 0.50, 0.56)
				env.fog_density = 0.016
				AudioManager.play_environment("res://assets/audio/rain_ambient.wav")
			_:
				env.fog_light_color = Color(0.66, 0.73, 0.80) if time_of_day != "night" else Color(0.08, 0.11, 0.16)
				env.fog_density = 0.006
				AudioManager.play_environment("res://assets/audio/birds_ambient.wav")
