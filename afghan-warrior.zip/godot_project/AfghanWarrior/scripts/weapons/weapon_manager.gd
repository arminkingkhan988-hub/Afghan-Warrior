extends Node3D
class_name WeaponManager

signal ammo_changed(mag: int, reserve: int, weapon_name: String, reloading: bool)
signal weapon_fired(origin: Vector3, hit_pos: Vector3)

var weapons: Array = []
var current_index: int = 0
var mag_ammo: Dictionary = {}
var reserve_ammo: Dictionary = {}
var fire_cooldown: float = 0.0
var is_reloading: bool = false
var reload_timer: float = 0.0
var grenades: int = 3
var tracer_pool: ObjectPool

@onready var muzzle_flash: OmniLight3D = $MuzzleFlash

func _ready() -> void:
	weapons = GameManager.weapons_cache.duplicate(true)
	if weapons.is_empty():
		weapons = [{"id":"khyber_47","name_en":"Khyber-47","name_ps":"خیبر-۴۷","damage":26,"fire_rate":0.11,"recoil":0.045,"spread":0.018,"mag_size":30,"reserve_max":180,"reload_time":1.6,"range":140.0,"pellets":1,"automatic":true,"zoom_fov":45.0,"sound":"res://assets/audio/rifle_shot.wav"}]
	for w in weapons:
		var wid := str(w["id"])
		mag_ammo[wid] = int(w["mag_size"])
		reserve_ammo[wid] = int(w["reserve_max"])
	if muzzle_flash:
		muzzle_flash.visible = false
	emit_ammo_update()

func set_starting_weapon(weapon_id: String) -> void:
	for i in range(weapons.size()):
		if str(weapons[i]["id"]) == weapon_id:
			current_index = i
			is_reloading = false
			emit_ammo_update()
			return

func get_current_weapon() -> Dictionary:
	return weapons[current_index]

func switch_next_weapon() -> void:
	if is_reloading:
		is_reloading = false
	current_index = (current_index + 1) % weapons.size()
	AudioManager.play_sfx("res://assets/audio/ui_click.wav", 1.1)
	emit_ammo_update()

func add_ammo(amount: int) -> void:
	var w := get_current_weapon()
	var wid := str(w["id"])
	reserve_ammo[wid] = mini(int(w["reserve_max"]), int(reserve_ammo[wid]) + amount)
	emit_ammo_update()

func _process(delta: float) -> void:
	if fire_cooldown > 0.0:
		fire_cooldown -= delta
	if is_reloading:
		reload_timer -= delta
		if reload_timer <= 0.0:
			_finish_reload()

func start_reload() -> void:
	if is_reloading:
		return
	var w := get_current_weapon()
	var wid := str(w["id"])
	var max_mag := int(w["mag_size"])
	if int(mag_ammo[wid]) >= max_mag or int(reserve_ammo[wid]) <= 0:
		return
	is_reloading = true
	reload_timer = float(w["reload_time"])
	AudioManager.play_sfx("res://assets/audio/reload.wav")
	emit_ammo_update()

func _finish_reload() -> void:
	var w := get_current_weapon()
	var wid := str(w["id"])
	var needed := int(w["mag_size"]) - int(mag_ammo[wid])
	var take := mini(needed, int(reserve_ammo[wid]))
	mag_ammo[wid] = int(mag_ammo[wid]) + take
	reserve_ammo[wid] = int(reserve_ammo[wid]) - take
	is_reloading = false
	emit_ammo_update()

func try_fire(cam: ThirdPersonCamera, shooter: Node3D) -> bool:
	if is_reloading or fire_cooldown > 0.0:
		return false
	var w := get_current_weapon()
	var wid := str(w["id"])
	if int(mag_ammo[wid]) <= 0:
		start_reload()
		return false

	mag_ammo[wid] = int(mag_ammo[wid]) - 1
	fire_cooldown = float(w["fire_rate"])
	AudioManager.play_sfx(str(w["sound"]), randf_range(0.95, 1.05))
	cam.add_recoil(float(w["recoil"]))

	if muzzle_flash:
		muzzle_flash.visible = true
		get_tree().create_timer(0.05).timeout.connect(func(): if is_instance_valid(muzzle_flash): muzzle_flash.visible = false)

	var space := get_world_3d().direct_space_state
	var origin := cam.get_aim_ray_origin()
	var base_dir := cam.get_aim_ray_direction()
	var pellets := int(w.get("pellets", 1))
	var spread := float(w["spread"]) * (0.45 if cam.is_aiming else 1.0)
	var hit_point := origin + base_dir * float(w["range"])

	for p in range(pellets):
		var dir := (base_dir + Vector3(randf_range(-spread, spread), randf_range(-spread, spread), randf_range(-spread, spread))).normalized()
		var query := PhysicsRayQueryParameters3D.create(origin, origin + dir * float(w["range"]))
		query.exclude = [shooter.get_rid()] if shooter is CollisionObject3D else []
		var result := space.intersect_ray(query)
		if not result.is_empty():
			hit_point = result["position"]
			var collider: Object = result["collider"]
			if collider and collider.has_method("apply_damage"):
				collider.apply_damage(int(w["damage"]), dir)
				AudioManager.play_sfx("res://assets/audio/hit_marker.wav")

	if tracer_pool:
		tracer_pool.spawn_tracer(global_position, hit_point)
	weapon_fired.emit(global_position, hit_point)
	emit_ammo_update()
	return true

func emit_ammo_update() -> void:
	var w := get_current_weapon()
	var wid := str(w["id"])
	var name_key := "name_ps" if LocalizationManager.is_rtl() else "name_en"
	ammo_changed.emit(int(mag_ammo[wid]), int(reserve_ammo[wid]), str(w.get(name_key, wid)), is_reloading)
