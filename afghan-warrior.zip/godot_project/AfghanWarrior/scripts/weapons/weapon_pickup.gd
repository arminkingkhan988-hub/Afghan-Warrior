extends Area3D
class_name WeaponPickup

@export var weapon_id: String = "khyber_47"
@export var ammo_amount: int = 30

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
	if body is PlayerController:
		body.weapon_manager.add_ammo(ammo_amount)
		AudioManager.play_sfx("res://assets/audio/reload.wav", 1.15)
		queue_free()
