extends RigidBody3D
class_name FragGrenade

@export var fuse_time: float = 2.4
@export var blast_radius: float = 8.0
@export var max_damage: int = 120

func _ready() -> void:
	get_tree().create_timer(fuse_time).timeout.connect(_detonate)

func _detonate() -> void:
	AudioManager.play_sfx("res://assets/audio/explosion.wav")
	for node in get_tree().get_nodes_in_group("damageable"):
		if node is Node3D:
			var dist := global_position.distance_to(node.global_position)
			if dist <= blast_radius and node.has_method("apply_damage"):
				var falloff := 1.0 - (dist / blast_radius)
				node.apply_damage(int(max_damage * falloff), (node.global_position - global_position).normalized())
	queue_free()
