extends Node3D
class_name ThirdPersonCamera

@export var default_fov: float = 65.0
@export var aim_fov: float = 44.0
@export var min_pitch: float = -55.0
@export var max_pitch: float = 45.0

@onready var spring_arm: SpringArm3D = $SpringArm3D
@onready var camera: Camera3D = $SpringArm3D/Camera3D

var yaw: float = 0.0
var pitch: float = -12.0
var is_aiming: bool = false
var target_aim_fov: float = 44.0
var recoil_pitch: float = 0.0

func _ready() -> void:
	camera.current = true
	spring_arm.spring_length = 3.4

func rotate_camera(delta_x: float, delta_y: float) -> void:
	var sens := SettingsManager.aim_sensitivity if is_aiming else SettingsManager.camera_sensitivity
	yaw -= delta_x * 0.18 * sens
	pitch = clampf(pitch - delta_y * 0.14 * sens, min_pitch, max_pitch)
	rotation_degrees.y = yaw
	spring_arm.rotation_degrees.x = pitch

func add_recoil(amount: float) -> void:
	recoil_pitch += amount * 14.0

func set_aiming(aiming: bool, weapon_zoom_fov: float = 44.0) -> void:
	is_aiming = aiming
	target_aim_fov = weapon_zoom_fov

func _process(delta: float) -> void:
	if recoil_pitch > 0.01:
		pitch = clampf(pitch + recoil_pitch * delta * 8.0, min_pitch, max_pitch)
		recoil_pitch = lerpf(recoil_pitch, 0.0, delta * 12.0)
		spring_arm.rotation_degrees.x = pitch
	var target_fov := target_aim_fov if is_aiming else default_fov
	camera.fov = lerpf(camera.fov, target_fov, delta * 10.0)
	var target_len := 2.0 if is_aiming else 3.4
	spring_arm.spring_length = lerpf(spring_arm.spring_length, target_len, delta * 10.0)

func get_aim_ray_origin() -> Vector3:
	return camera.global_position

func get_aim_ray_direction() -> Vector3:
	return -camera.global_transform.basis.z.normalized()
