extends CharacterBody3D
class_name PlayerController

signal health_changed(health: int, armor: int)
signal player_died
signal interaction_prompt_changed(text: String, visible: bool)

@export var walk_speed: float = 4.6
@export var sprint_speed: float = 7.6
@export var crouch_speed: float = 2.6
@export var jump_velocity: float = 5.4
@export var gravity: float = 15.0

var health: int = 100
var max_health: int = 100
var armor: int = 50
var max_armor: int = 50
var is_crouching: bool = false
var is_sprinting: bool = false
var is_dead: bool = false
var active_vehicle: Node = null
var nearby_interactable: Node = null
var step_timer: float = 0.0

var mobile_move_input: Vector2 = Vector2.ZERO
var mobile_aiming: bool = false
var mobile_firing: bool = false

@onready var camera_rig: ThirdPersonCamera = $CameraRig
@onready var model_root: Node3D = $SoldierModel
@onready var weapon_manager: WeaponManager = $SoldierModel/WeaponMount/WeaponManager
@onready var collision_shape: CollisionShape3D = $CollisionShape3D

func _ready() -> void:
	add_to_group("player")
	add_to_group("damageable")
	health_changed.emit(health, armor)

func set_mobile_move(vec: Vector2) -> void:
	mobile_move_input = vec

func set_mobile_look(delta_x: float, delta_y: float) -> void:
	if camera_rig:
		camera_rig.rotate_camera(delta_x, delta_y)

func _unhandled_input(event: InputEvent) -> void:
	if is_dead:
		return
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		camera_rig.rotate_camera(event.relative.x, event.relative.y)
	if event.is_action_pressed("reload"):
		weapon_manager.start_reload()
	elif event.is_action_pressed("switch_weapon"):
		weapon_manager.switch_next_weapon()
	elif event.is_action_pressed("crouch"):
		toggle_crouch()
	elif event.is_action_pressed("interact"):
		try_interact()
	elif event.is_action_pressed("throw_grenade"):
		throw_grenade()

func toggle_crouch() -> void:
	is_crouching = not is_crouching
	if model_root:
		model_root.scale.y = 0.72 if is_crouching else 1.0

func try_interact() -> void:
	if active_vehicle and active_vehicle.has_method("exit_vehicle"):
		active_vehicle.exit_vehicle(self)
		active_vehicle = null
		visible = true
		return
	if nearby_interactable and nearby_interactable.has_method("interact"):
		nearby_interactable.interact(self)

func throw_grenade() -> void:
	if weapon_manager.grenades <= 0:
		return
	weapon_manager.grenades -= 1
	var grenade_scene := load("res://scenes/weapons/grenade.tscn") as PackedScene
	if grenade_scene:
		var g := grenade_scene.instantiate() as RigidBody3D
		get_parent().add_child(g)
		g.global_position = global_position + Vector3(0, 1.4, 0) + camera_rig.get_aim_ray_direction() * 1.0
		g.apply_central_impulse(camera_rig.get_aim_ray_direction() * 14.0 + Vector3(0, 4.5, 0))

func _physics_process(delta: float) -> void:
	if is_dead:
		return
	if active_vehicle:
		global_position = active_vehicle.global_position + Vector3(0, 1.5, 0)
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	var input_vec := Vector2(
		Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
		Input.get_action_strength("move_backward") - Input.get_action_strength("move_forward")
	)
	if mobile_move_input.length() > 0.08:
		input_vec = Vector2(mobile_move_input.x, mobile_move_input.y)

	is_sprinting = Input.is_action_pressed("sprint") and input_vec.y < -0.2 and not is_crouching
	var aiming := Input.is_action_pressed("aim") or mobile_aiming
	var current_w := weapon_manager.get_current_weapon()
	camera_rig.set_aiming(aiming, float(current_w.get("zoom_fov", 45.0)))

	var basis := camera_rig.global_transform.basis
	var forward := Vector3(basis.z.x, 0, basis.z.z).normalized()
	var right := Vector3(basis.x.x, 0, basis.x.z).normalized()
	var move_dir := (right * input_vec.x + forward * input_vec.y)
	if move_dir.length() > 1.0:
		move_dir = move_dir.normalized()

	var speed := crouch_speed if is_crouching else (sprint_speed if is_sprinting else walk_speed)
	velocity.x = move_dir.x * speed
	velocity.z = move_dir.z * speed
	move_and_slide()

	if move_dir.length() > 0.1 and is_on_floor():
		step_timer -= delta
		if step_timer <= 0.0:
			AudioManager.play_sfx("res://assets/audio/footstep_dirt.wav", randf_range(0.9, 1.15))
			step_timer = 0.28 if is_sprinting else 0.44

	if model_root:
		var look_dir := -Vector3(basis.z.x, 0, basis.z.z).normalized()
		if look_dir.length() > 0.01:
			model_root.rotation.y = lerp_angle(model_root.rotation.y, atan2(look_dir.x, look_dir.z), delta * 12.0)

	var firing := Input.is_action_pressed("shoot") or mobile_firing
	if firing:
		weapon_manager.try_fire(camera_rig, self)

func apply_damage(amount: int, _dir: Vector3 = Vector3.ZERO) -> void:
	if is_dead:
		return
	if armor > 0:
		var absorbed := mini(armor, int(amount * 0.6))
		armor -= absorbed
		amount -= absorbed
	health = maxi(0, health - amount)
	health_changed.emit(health, armor)
	if health <= 0:
		is_dead = true
		if model_root:
			model_root.rotation_degrees.x = 85.0
		player_died.emit()
