extends Node3D

@onready var hud: Control = $HUD
@onready var mobile_controls: Control = $MobileControls
@onready var pause_menu: Control = $PauseMenu
@onready var pool: ObjectPool = $ObjectPool

var player: PlayerController
var remaining_enemies: int = 0
var mission_data: Dictionary = {}

func _ready() -> void:
	var map_scene_path := "res://scenes/maps/map_afghan_village.tscn"
	var enemy_count := 5
	var diff := "veteran"
	var tod := "day"
	var weather := "clear"
	var starting_weapon := "khyber_47"

	if GameManager.active_mode == GameManager.GameMode.STORY:
		mission_data = GameManager.get_mission_by_id(GameManager.active_mission_id)
		map_scene_path = str(mission_data.get("map_scene", map_scene_path))
		enemy_count = int(mission_data.get("enemy_count", 5))
		diff = str(mission_data.get("difficulty", "veteran"))
		tod = str(mission_data.get("time_of_day", "day"))
		weather = str(mission_data.get("weather", "clear"))
	else:
		var cfg := GameManager.free_battle_config
		map_scene_path = str(cfg.get("map_scene", map_scene_path))
		enemy_count = int(cfg.get("enemy_count", 6))
		diff = str(cfg.get("difficulty", "veteran"))
		tod = str(cfg.get("time_of_day", "day"))
		weather = str(cfg.get("weather", "clear"))
		starting_weapon = str(cfg.get("starting_weapon", "khyber_47"))

	var map_scene := load(map_scene_path) as PackedScene
	var map_node := map_scene.instantiate()
	add_child(map_node)

	var env_ctrl := map_node.get_node_or_null("EnvironmentController")
	if env_ctrl and env_ctrl.has_method("apply_conditions"):
		env_ctrl.apply_conditions(tod, weather)

	var player_scene := load("res://scenes/player/player.tscn") as PackedScene
	player = player_scene.instantiate() as PlayerController
	add_child(player)
	player.global_position = Vector3(0, 1.5, 22)
	player.weapon_manager.tracer_pool = pool
	player.weapon_manager.set_starting_weapon(starting_weapon)

	_wire_ui()
	_spawn_enemies(enemy_count, diff)

func _wire_ui() -> void:
	if mobile_controls and mobile_controls.has_method("bind_player"):
		mobile_controls.bind_player(player)
	if hud and hud.has_method("bind_player"):
		hud.bind_player(player)
		var obj_text := str(mission_data.get("objective_ps" if LocalizationManager.is_rtl() else "objective_en", LocalizationManager.tr_key("HUD_OBJECTIVE")))
		hud.set_objective(obj_text)
	player.player_died.connect(_on_player_died)

func _spawn_enemies(count: int, diff: String) -> void:
	var enemy_scene := load("res://scenes/enemies/enemy_soldier.tscn") as PackedScene
	remaining_enemies = count
	for i in range(count):
		var e := enemy_scene.instantiate() as EnemyAI
		add_child(e)
		var angle := (TAU / maxf(1.0, float(count))) * float(i)
		e.global_position = Vector3(cos(angle) * 18.0, 1.5, sin(angle) * 14.0 - 8.0)
		e.configure_difficulty(diff)
		e.died.connect(_on_enemy_died)
	if hud and hud.has_method("set_enemy_count"):
		hud.set_enemy_count(remaining_enemies)

func _on_enemy_died(_enemy: EnemyAI) -> void:
	remaining_enemies = maxi(0, remaining_enemies - 1)
	if hud and hud.has_method("set_enemy_count"):
		hud.set_enemy_count(remaining_enemies)
	if remaining_enemies == 0:
		if GameManager.active_mode == GameManager.GameMode.STORY:
			SaveManager.mark_mission_completed(
				int(mission_data.get("id", 1)),
				int(mission_data.get("reward_points", 250)),
				int(mission_data.get("unlocks_mission", 2))
			)
		if pause_menu and pause_menu.has_method("show_result"):
			pause_menu.show_result(true)

func _on_player_died() -> void:
	if pause_menu and pause_menu.has_method("show_result"):
		pause_menu.show_result(false)
