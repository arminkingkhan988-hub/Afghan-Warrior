import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Crosshair,
  Download,
  FolderArchive,
  Gamepad2,
  Globe,
  Info,
  Pause,
  Play,
  RotateCcw,
  Settings,
  Shield,
  Sliders,
  Swords,
  Volume2,
} from 'lucide-react';
import { GameCanvas, type MobileControlBridge } from './components/GameCanvas';
import { MobileControlsOverlay } from './components/MobileControlsOverlay';
import { ProjectExplorerModal } from './components/ProjectExplorerModal';
import { gameAudio } from './game/audio';
import { MISSIONS, t, WEAPONS } from './game/i18n';
import type {
  Difficulty,
  FreeBattleConfig,
  GameMode,
  GraphicsPreset,
  HudSnapshot,
  Language,
  MapId,
  SaveState,
  TimeOfDay,
  Weather,
} from './game/types';

const STORAGE_KEY = 'afghan_warrior_save_v1';

const DEFAULT_SAVE: SaveState = {
  language: 'en',
  graphicsQuality: 'medium',
  musicVolume: 0.65,
  sfxVolume: 0.85,
  envVolume: 0.6,
  cameraSensitivity: 1.0,
  aimSensitivity: 0.65,
  controlSensitivity: 1.0,
  unlockedMission: 1,
  completedMissions: [],
  totalScore: 0,
};

function loadSaveState(): SaveState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE;
    return { ...DEFAULT_SAVE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SAVE;
  }
}

type ScreenView = 'menu' | 'missions' | 'freeBattle' | 'weapons' | 'settings' | 'about' | 'playing';

export default function App() {
  const [save, setSave] = useState<SaveState>(loadSaveState);
  const [screen, setScreen] = useState<ScreenView>('menu');
  const [explorerOpen, setExplorerOpen] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  const [activeMode, setActiveMode] = useState<GameMode>('story');
  const [activeMissionId, setActiveMissionId] = useState<number>(1);
  const [freeConfig, setFreeConfig] = useState<FreeBattleConfig>({
    mapId: 'village',
    difficulty: 'veteran',
    enemyCount: 6,
    startingWeapon: 'khyber_47',
    timeOfDay: 'day',
    weather: 'clear',
  });

  const [paused, setPaused] = useState(false);
  const [resultState, setResultState] = useState<'none' | 'victory' | 'defeat'>('none');
  const [runKey, setRunKey] = useState(1);
  const [touchHudVisible, setTouchHudVisible] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 960 : false
  );

  const [hud, setHud] = useState<HudSnapshot>({
    health: 100,
    maxHealth: 100,
    armor: 50,
    maxArmor: 50,
    magAmmo: 30,
    reserveAmmo: 180,
    weaponId: 'khyber_47',
    weaponName: 'Khyber-47 Tactical',
    grenades: 3,
    isReloading: false,
    isAiming: false,
    isCrouching: false,
    inVehicle: false,
    nearbyVehicle: false,
    enemiesRemaining: 5,
    enemiesTotal: 5,
    objectiveText: '',
    statusBanner: null,
  });

  const mobileBridgeRef = useRef<MobileControlBridge>({
    moveX: 0,
    moveY: 0,
    lookDeltaX: 0,
    lookDeltaY: 0,
    firing: false,
    aiming: false,
    sprinting: false,
    triggerJump: false,
    triggerCrouch: false,
    triggerReload: false,
    triggerSwitch: false,
    triggerGrenade: false,
    triggerInteract: false,
  });

  const lang: Language = save.language;
  const isRtl = lang === 'ps';

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
    } catch {
      // storage unavailable
    }
    gameAudio.setVolumes(save.musicVolume, save.sfxVolume, save.envVolume);
  }, [save]);

  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [isRtl, lang]);

  const activeMission = MISSIONS.find((m) => m.id === activeMissionId) || MISSIONS[0];

  const launchStoryMission = (missionId: number) => {
    gameAudio.playUiClick();
    gameAudio.stopMenuPulse();
    setActiveMode('story');
    setActiveMissionId(missionId);
    setPaused(false);
    setResultState('none');
    setRunKey((k) => k + 1);
    setScreen('playing');
  };

  const launchFreeBattle = (cfg: FreeBattleConfig) => {
    gameAudio.playUiClick();
    gameAudio.stopMenuPulse();
    setActiveMode('free');
    setFreeConfig(cfg);
    setPaused(false);
    setResultState('none');
    setRunKey((k) => k + 1);
    setScreen('playing');
  };

  const handleMissionEnd = useCallback(
    (victory: boolean) => {
      setResultState(victory ? 'victory' : 'defeat');
      setPaused(true);
      if (document.pointerLockElement) {
        document.exitPointerLock?.();
      }
      if (victory && activeMode === 'story') {
        setSave((prev) => {
          const completed = prev.completedMissions.includes(activeMission.id)
            ? prev.completedMissions
            : [...prev.completedMissions, activeMission.id];
          return {
            ...prev,
            completedMissions: completed,
            unlockedMission: Math.max(prev.unlockedMission, activeMission.unlocksMission),
            totalScore: prev.totalScore + activeMission.rewardPoints,
          };
        });
      }
    },
    [activeMode, activeMission]
  );

  const toggleLanguage = () => {
    gameAudio.playUiClick();
    setSave((prev) => ({ ...prev, language: prev.language === 'en' ? 'ps' : 'en' }));
  };

  const currentMap: MapId = activeMode === 'story' ? activeMission.mapId : freeConfig.mapId;
  const currentDifficulty: Difficulty = activeMode === 'story' ? activeMission.difficulty : freeConfig.difficulty;
  const currentEnemyCount = activeMode === 'story' ? activeMission.enemyCount : freeConfig.enemyCount;
  const currentWeapon = activeMode === 'story' ? 'khyber_47' : freeConfig.startingWeapon;
  const currentTime: TimeOfDay = activeMode === 'story' ? activeMission.timeOfDay : freeConfig.timeOfDay;
  const currentWeather: Weather = activeMode === 'story' ? activeMission.weather : freeConfig.weather;
  const currentObjective =
    activeMode === 'story'
      ? isRtl
        ? activeMission.objectivePs
        : activeMission.objectiveEn
      : isRtl
        ? `${t('ps', 'freeBattle')} · ${currentEnemyCount} ${t('ps', 'hostiles')}`
        : `${t('en', 'freeBattle')} · ${currentEnemyCount} ${t('en', 'hostiles')}`;

  if (screen === 'playing') {
    return (
      <div className="relative w-screen h-screen overflow-hidden bg-[#0F1115]" dir={isRtl ? 'rtl' : 'ltr'}>
        <GameCanvas
          mapId={currentMap}
          difficulty={currentDifficulty}
          enemyCount={currentEnemyCount}
          startingWeaponId={currentWeapon}
          timeOfDay={currentTime}
          weather={currentWeather}
          objectiveText={currentObjective}
          graphicsQuality={save.graphicsQuality}
          cameraSensitivity={save.cameraSensitivity}
          aimSensitivity={save.aimSensitivity}
          paused={paused}
          language={lang}
          runKey={runKey}
          mobileBridgeRef={mobileBridgeRef}
          onHudUpdate={setHud}
          onMissionEnd={handleMissionEnd}
          onRequestPause={() => setPaused(true)}
        />

        {/* Center Crosshair */}
        {!paused && (
          <div className="fixed inset-0 pointer-events-none flex items-center justify-center z-10">
            <div className={`relative transition-transform duration-100 ${hud.isAiming ? 'scale-75' : 'scale-100'}`}>
              <div className="w-5 h-[2px] bg-[#F5E1A5]/85 absolute -left-6 top-0" />
              <div className="w-5 h-[2px] bg-[#F5E1A5]/85 absolute left-1 top-0" />
              <div className="h-5 w-[2px] bg-[#F5E1A5]/85 absolute left-0 -top-6" />
              <div className="h-5 w-[2px] bg-[#F5E1A5]/85 absolute left-0 top-1" />
              <div className="w-1 h-1 rounded-full bg-[#D99B26] -translate-x-0.5 -translate-y-0.5" />
            </div>
          </div>
        )}

        {/* Top-Left Health & Armor HUD (No backdrop-filter over WebGL) */}
        <div className="fixed top-4 left-4 z-10 w-60 bg-[#12161D]/88 border border-white/15 rounded-lg p-3 pointer-events-none" dir="ltr">
          <div className="flex items-center justify-between text-xs text-[#E2E8F0] mb-1">
            <span>{t(lang, 'health')}</span>
            <span className="font-mono-num font-bold">{hud.health}</span>
          </div>
          <div className="h-2 w-full bg-white/10 rounded-sm overflow-hidden mb-2.5">
            <div
              className="h-full bg-[#C93B2B] transition-all duration-150"
              style={{ width: `${(hud.health / hud.maxHealth) * 100}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-xs text-[#CBD5E1] mb-1">
            <span>{t(lang, 'armor')}</span>
            <span className="font-mono-num font-bold">{hud.armor}</span>
          </div>
          <div className="h-1.5 w-full bg-white/10 rounded-sm overflow-hidden">
            <div
              className="h-full bg-[#3882B8] transition-all duration-150"
              style={{ width: `${(hud.armor / hud.maxArmor) * 100}%` }}
            />
          </div>
        </div>

        {/* Top-Center Mission Objective & Hostiles Counter */}
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-10 bg-[#12161D]/88 border border-white/15 rounded-lg px-4 py-2 text-center pointer-events-none max-w-md">
          <div className="text-xs font-medium text-[#F4C462] truncate">{hud.objectiveText}</div>
          <div className="text-xs text-[#CBD5E1] font-mono-num mt-0.5">
            {t(lang, 'hostiles')}: {hud.enemiesRemaining} / {hud.enemiesTotal}
          </div>
        </div>

        {/* Top-Right Controls */}
        {!touchHudVisible && (
          <div className="fixed top-4 right-4 z-20 flex items-center gap-2">
            <button
              onClick={() => setTouchHudVisible(true)}
              className="px-3 py-2 rounded-lg bg-[#12161D]/88 border border-white/15 text-xs font-medium text-[#E2E8F0] hover:bg-[#1E242E]"
            >
              Touch HUD
            </button>
            <button
              onClick={() => setPaused(true)}
              className="px-3.5 py-2 rounded-lg bg-[#12161D]/88 border border-white/15 text-xs font-medium text-[#E2E8F0] hover:bg-[#1E242E] inline-flex items-center gap-1.5"
            >
              <Pause className="w-3.5 h-3.5" />
              <span>{t(lang, 'pauseBtn')}</span>
            </button>
          </div>
        )}

        {/* Vehicle / Context Prompt */}
        {hud.statusBanner && !paused && (
          <div className="fixed bottom-28 left-1/2 -translate-x-1/2 z-10 bg-[#12161D]/92 border border-[#D99B26]/50 rounded-lg px-4 py-2 text-xs font-medium text-[#F4C462] pointer-events-none">
            {hud.statusBanner}
          </div>
        )}

        {/* Bottom-Right Weapon & Ammo HUD (Desktop placement; shifted slightly up if Touch HUD active) */}
        <div
          className={`fixed right-4 z-10 bg-[#12161D]/88 border border-white/15 rounded-lg px-4 py-2.5 text-end pointer-events-none ${
            touchHudVisible ? 'top-16' : 'bottom-5'
          }`}
          dir="ltr"
        >
          <div className="text-xs text-[#C2A878] font-medium">{hud.weaponName}</div>
          <div className="font-mono-num text-xl font-bold text-white mt-0.5">
            {hud.isReloading ? t(lang, 'reloading') : `${hud.magAmmo} / ${hud.reserveAmmo}`}
          </div>
          <div className="text-[11px] text-[#9CA3AF] font-mono-num mt-0.5">
            {t(lang, 'grenades')}: {hud.grenades}
          </div>
        </div>

        {/* Desktop quick keyboard bar */}
        {!touchHudVisible && !paused && (
          <div className="fixed bottom-4 left-4 z-10 bg-[#12161D]/80 border border-white/10 rounded-lg px-3 py-1.5 text-[11px] text-[#CBD5E1] pointer-events-none max-w-2xl">
            {t(lang, 'controlsHint')}
          </div>
        )}

        <MobileControlsOverlay
          bridgeRef={mobileBridgeRef}
          language={lang}
          controlSensitivity={save.controlSensitivity}
          visible={touchHudVisible && !paused}
          nearbyVehicle={hud.nearbyVehicle}
          inVehicle={hud.inVehicle}
          isAiming={hud.isAiming}
          isCrouching={hud.isCrouching}
          onPause={() => setPaused(true)}
        />

        {/* Pause / Mission Result Overlay */}
        {paused && (
          <div className="fixed inset-0 z-40 bg-black/75 flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[#161A20] border border-white/15 rounded-xl p-6 text-center space-y-5">
              <h2 className="font-display text-2xl font-bold tracking-wide text-white">
                {resultState === 'victory'
                  ? t(lang, 'victory')
                  : resultState === 'defeat'
                    ? t(lang, 'defeat')
                    : t(lang, 'paused')}
              </h2>

              {resultState === 'victory' && activeMode === 'story' && (
                <p className="text-sm text-[#C2A878]">
                  +{activeMission.rewardPoints} {t(lang, 'scoreLabel')}
                </p>
              )}

              <div className="flex flex-col gap-2.5">
                {resultState === 'none' && (
                  <button
                    onClick={() => setPaused(false)}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-sm"
                  >
                    {t(lang, 'resume')}
                  </button>
                )}

                {resultState === 'victory' && activeMode === 'story' && activeMission.id < 3 && (
                  <button
                    onClick={() => launchStoryMission(activeMission.id + 1)}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-sm"
                  >
                    {t(lang, 'nextMission')}
                  </button>
                )}

                <button
                  onClick={() => {
                    setPaused(false);
                    setResultState('none');
                    setRunKey((k) => k + 1);
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-white/10 hover:bg-white/15 text-white font-medium text-sm inline-flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>{resultState === 'none' ? t(lang, 'restart') : t(lang, 'retry')}</span>
                </button>

                {resultState === 'none' && (
                  <button
                    onClick={() => setTouchHudVisible((v) => !v)}
                    className="w-full py-2.5 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-[#CBD5E1] text-sm"
                  >
                    {touchHudVisible ? 'Hide Mobile Touch HUD' : 'Show Mobile Touch HUD'}
                  </button>
                )}

                <button
                  onClick={() => {
                    setPaused(false);
                    setResultState('none');
                    setScreen('menu');
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-[#CBD5E1] text-sm"
                >
                  {t(lang, 'mainMenu')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#F1F3F5] flex flex-col" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Clean 3-Zone Top Bar Contract */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-white/10 bg-[#12151A]">
        <button
          onClick={() => setScreen('menu')}
          className="font-display text-xl font-bold tracking-wider text-white whitespace-nowrap shrink-0"
        >
          {t(lang, 'appTitle')}
        </button>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#CBD5E1]">
          <button
            onClick={() => setScreen('missions')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              screen === 'missions' ? 'text-[#F4C462] underline underline-offset-4' : ''
            }`}
          >
            {t(lang, 'missions')}
          </button>
          <button
            onClick={() => setScreen('freeBattle')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              screen === 'freeBattle' ? 'text-[#F4C462] underline underline-offset-4' : ''
            }`}
          >
            {t(lang, 'freeBattle')}
          </button>
          <button
            onClick={() => setScreen('weapons')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              screen === 'weapons' ? 'text-[#F4C462] underline underline-offset-4' : ''
            }`}
          >
            {t(lang, 'weapons')}
          </button>
          <button
            onClick={() => setScreen('settings')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              screen === 'settings' ? 'text-[#F4C462] underline underline-offset-4' : ''
            }`}
          >
            {t(lang, 'settings')}
          </button>
          <button
            onClick={() => setScreen('about')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              screen === 'about' ? 'text-[#F4C462] underline underline-offset-4' : ''
            }`}
          >
            {t(lang, 'about')}
          </button>
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setExplorerOpen(true)}
            className="px-4 py-2 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] text-xs font-semibold inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
          >
            <FolderArchive className="w-4 h-4" />
            <span>{t(lang, 'godotPackage')}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col">
        {screen === 'menu' && (
          <section className="relative flex-1 flex items-center">
            <img
              src="/src/assets/images/afghan_mountain_backdrop_1795589856641.jpg"
              alt="Afghan mountain valley compounds"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0F1115]/95 via-[#0F1115]/80 to-[#0F1115]/45" />

            <div className="relative z-10 w-full max-w-6xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              <div className="lg:col-span-7 space-y-6">
                <div className="text-xs font-medium text-[#C2A878] tracking-wide">
                  <span>Godot 4.x Android APK</span>
                  <span aria-hidden="true" className="mx-2">·</span>
                  <span>Three.js Playable Preview</span>
                  <span aria-hidden="true" className="mx-2">·</span>
                  <span>{t(lang, 'scoreLabel')}: <span className="font-mono-num">{save.totalScore}</span></span>
                </div>

                <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white text-balance">
                  {t(lang, 'appTitle')}
                </h1>

                <p className="text-base text-[#D1D5DB] max-w-xl leading-relaxed">
                  {t(lang, 'aboutBody')}
                </p>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => launchStoryMission(Math.min(save.unlockedMission, 3))}
                    className="px-6 py-3 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-sm inline-flex items-center gap-2 whitespace-nowrap transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    <span>{t(lang, 'play')} — {t(lang, 'storyMode')}</span>
                  </button>

                  <button
                    onClick={() => setScreen('freeBattle')}
                    className="px-5 py-3 rounded-lg bg-[#1A1F27] hover:bg-[#232A35] border border-white/15 text-white font-medium text-sm inline-flex items-center gap-2 whitespace-nowrap transition-colors"
                  >
                    <Swords className="w-4 h-4 text-[#C2A878]" />
                    <span>{t(lang, 'freeBattle')}</span>
                  </button>

                  <button
                    onClick={toggleLanguage}
                    className="px-4 py-3 rounded-lg bg-[#1A1F27] hover:bg-[#232A35] border border-white/15 text-[#E2E8F0] font-medium text-sm inline-flex items-center gap-2 whitespace-nowrap transition-colors"
                  >
                    <Globe className="w-4 h-4 text-[#D99B26]" />
                    <span>{isRtl ? t(lang, 'langEnglish') : t(lang, 'langPashto')}</span>
                  </button>
                </div>
              </div>

              <div className="lg:col-span-5 bg-[#14181F]/92 border border-white/15 rounded-xl p-6 space-y-4">
                <h2 className="font-display text-lg font-semibold text-white">
                  {isRtl ? 'د انډرایډ پروژه او چټک مینو' : 'Operations & Android Deliverable'}
                </h2>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    onClick={() => setScreen('missions')}
                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-start text-sm font-medium text-[#E2E8F0] flex items-center gap-2.5"
                  >
                    <Shield className="w-4 h-4 text-[#D99B26] shrink-0" />
                    <span className="truncate">{t(lang, 'missions')}</span>
                  </button>
                  <button
                    onClick={() => setScreen('weapons')}
                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-start text-sm font-medium text-[#E2E8F0] flex items-center gap-2.5"
                  >
                    <Crosshair className="w-4 h-4 text-[#D99B26] shrink-0" />
                    <span className="truncate">{t(lang, 'weapons')}</span>
                  </button>
                  <button
                    onClick={() => setScreen('settings')}
                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-start text-sm font-medium text-[#E2E8F0] flex items-center gap-2.5"
                  >
                    <Settings className="w-4 h-4 text-[#D99B26] shrink-0" />
                    <span className="truncate">{t(lang, 'settings')}</span>
                  </button>
                  <button
                    onClick={() => setScreen('about')}
                    className="p-3 rounded-lg bg-white/5 hover:bg-white/10 text-start text-sm font-medium text-[#E2E8F0] flex items-center gap-2.5"
                  >
                    <Info className="w-4 h-4 text-[#D99B26] shrink-0" />
                    <span className="truncate">{t(lang, 'about')}</span>
                  </button>
                </div>

                <div className="pt-3 border-t border-white/10 space-y-2.5">
                  <a
                    href="/Afghan_Warrior_Complete_Project.zip"
                    download="Afghan_Warrior_Complete_Project.zip"
                    className="w-full py-2.5 px-4 rounded-lg bg-[#202731] hover:bg-[#2A3340] border border-[#D99B26]/40 text-[#F4C462] text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>{t(lang, 'downloadZip')}</span>
                  </a>
                  <button
                    onClick={() => setExplorerOpen(true)}
                    className="w-full py-2 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-[#CBD5E1] transition-colors"
                  >
                    {isRtl ? 'د Godot 4 فایلونه وګورئ' : 'Inspect Godot 4 Project Files'}
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {screen === 'missions' && (
          <section className="max-w-5xl w-full mx-auto px-6 py-10 space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl font-bold text-white">{t(lang, 'missions')}</h1>
                <p className="text-sm text-[#9CA3AF] mt-1">
                  {isRtl ? 'لومړي ۳ ماموریتونه بشپړ د لوبې وړ دي؛ ۴ تر ۱۰ د راتلونکي پراختیا لپاره چمتو دي.' : 'Missions 1–3 are fully playable vertical-slice operations; Missions 4–10 are structured campaign blueprints.'}
                </p>
              </div>
              <button onClick={() => setScreen('menu')} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold">
                {t(lang, 'back')}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {MISSIONS.map((m) => {
                const unlocked = m.id <= save.unlockedMission;
                const completed = save.completedMissions.includes(m.id);
                return (
                  <div
                    key={m.id}
                    className="bg-[#161A20] border border-white/10 rounded-xl p-5 flex flex-col justify-between gap-4"
                  >
                    <div className="space-y-2">
                      <div className="text-xs text-[#9CA3AF] flex items-center gap-2">
                        <span className="font-mono-num">0{m.id}</span>
                        <span aria-hidden="true">·</span>
                        <span>{t(lang, m.mapId === 'village' ? 'mapVillage' : m.mapId === 'valley' ? 'mapValley' : 'mapOutpost')}</span>
                        <span aria-hidden="true">·</span>
                        <span className={m.implemented ? 'text-[#F4C462]' : 'text-[#9CA3AF]'}>
                          {m.implemented ? t(lang, 'playableBadge') : 'Blueprint'}
                        </span>
                        {completed && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-[#6EE7B7]">Completed</span>
                          </>
                        )}
                      </div>
                      <h3 className="font-display text-lg font-semibold text-white">
                        {isRtl ? m.titlePs : m.titleEn}
                      </h3>
                      <p className="text-sm text-[#CBD5E1] leading-relaxed">
                        {isRtl ? m.briefingPs : m.briefingEn}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-white/10">
                      <span className="text-xs font-mono-num text-[#C2A878]">
                        {m.enemyCount} {t(lang, 'hostiles')} · +{m.rewardPoints} pts
                      </span>
                      {m.implemented ? (
                        <button
                          disabled={!unlocked}
                          onClick={() => launchStoryMission(m.id)}
                          className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap ${
                            unlocked
                              ? 'bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115]'
                              : 'bg-white/5 text-[#6B7280] cursor-not-allowed'
                          }`}
                        >
                          {unlocked ? t(lang, 'play') : t(lang, 'lockedMission')}
                        </button>
                      ) : (
                        <button
                          onClick={() =>
                            launchFreeBattle({
                              mapId: m.mapId,
                              difficulty: m.difficulty,
                              enemyCount: m.enemyCount,
                              startingWeapon: 'khyber_47',
                              timeOfDay: m.timeOfDay,
                              weather: m.weather,
                            })
                          }
                          className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-medium text-white whitespace-nowrap"
                        >
                          {t(lang, 'freeBattle')}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {screen === 'freeBattle' && (
          <section className="max-w-3xl w-full mx-auto px-6 py-10 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-3xl font-bold text-white">{t(lang, 'freeBattle')}</h1>
              <button onClick={() => setScreen('menu')} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold">
                {t(lang, 'back')}
              </button>
            </div>

            <div className="bg-[#161A20] border border-white/10 rounded-xl p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">{t(lang, 'mapLabel')}</span>
                  <select
                    value={freeConfig.mapId}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, mapId: e.target.value as MapId }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="village">{t(lang, 'mapVillage')}</option>
                    <option value="valley">{t(lang, 'mapValley')}</option>
                    <option value="outpost">{t(lang, 'mapOutpost')}</option>
                  </select>
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">{t(lang, 'difficultyLabel')}</span>
                  <select
                    value={freeConfig.difficulty}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, difficulty: e.target.value as Difficulty }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="recruit">{t(lang, 'diffRecruit')}</option>
                    <option value="veteran">{t(lang, 'diffVeteran')}</option>
                    <option value="elite">{t(lang, 'diffElite')}</option>
                  </select>
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">{t(lang, 'weaponLabel')}</span>
                  <select
                    value={freeConfig.startingWeapon}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, startingWeapon: e.target.value }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    {WEAPONS.map((w) => (
                      <option key={w.id} value={w.id}>
                        {isRtl ? w.namePs : w.nameEn}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">
                    {t(lang, 'enemyCountLabel')}: <span className="font-mono-num text-[#F4C462]">{freeConfig.enemyCount}</span>
                  </span>
                  <input
                    type="range"
                    min={2}
                    max={18}
                    value={freeConfig.enemyCount}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, enemyCount: Number(e.target.value) }))}
                    className="w-full accent-[#D99B26] mt-2"
                  />
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">{t(lang, 'timeLabel')}</span>
                  <select
                    value={freeConfig.timeOfDay}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, timeOfDay: e.target.value as TimeOfDay }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="day">{t(lang, 'timeDay')}</option>
                    <option value="dusk">{t(lang, 'timeDusk')}</option>
                    <option value="night">{t(lang, 'timeNight')}</option>
                  </select>
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] block">{t(lang, 'weatherLabel')}</span>
                  <select
                    value={freeConfig.weather}
                    onChange={(e) => setFreeConfig((c) => ({ ...c, weather: e.target.value as Weather }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="clear">{t(lang, 'weatherClear')}</option>
                    <option value="dust">{t(lang, 'weatherDust')}</option>
                    <option value="rain">{t(lang, 'weatherRain')}</option>
                  </select>
                </label>
              </div>

              <button
                onClick={() => launchFreeBattle(freeConfig)}
                className="w-full py-3 px-6 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors"
              >
                <Gamepad2 className="w-4 h-4" />
                <span>{t(lang, 'deploy')}</span>
              </button>
            </div>
          </section>
        )}

        {screen === 'weapons' && (
          <section className="max-w-5xl w-full mx-auto px-6 py-10 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-3xl font-bold text-white">{t(lang, 'weapons')}</h1>
              <button onClick={() => setScreen('menu')} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold">
                {t(lang, 'back')}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {WEAPONS.map((w) => (
                <div key={w.id} className="bg-[#161A20] border border-white/10 rounded-xl p-5 space-y-3">
                  <div className="text-xs text-[#C2A878]">{isRtl ? w.categoryPs : w.categoryEn}</div>
                  <h3 className="font-display text-xl font-semibold text-white">{isRtl ? w.namePs : w.nameEn}</h3>
                  <div className="grid grid-cols-2 gap-y-2 text-xs text-[#CBD5E1] pt-2 border-t border-white/10 font-mono-num">
                    <span>Damage: {w.damage}{w.pellets > 1 ? ` x${w.pellets}` : ''}</span>
                    <span>Mag: {w.magSize} / {w.reserveMax}</span>
                    <span>Range: {w.range}m</span>
                    <span>Reload: {w.reloadTime}s</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {screen === 'settings' && (
          <section className="max-w-3xl w-full mx-auto px-6 py-10 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-3xl font-bold text-white">{t(lang, 'settings')}</h1>
              <button onClick={() => setScreen('menu')} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold">
                {t(lang, 'back')}
              </button>
            </div>

            <div className="bg-[#161A20] border border-white/10 rounded-xl p-6 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] flex items-center gap-2">
                    <Globe className="w-4 h-4 text-[#D99B26]" />
                    <span>{t(lang, 'language')}</span>
                  </span>
                  <select
                    value={save.language}
                    onChange={(e) => setSave((s) => ({ ...s, language: e.target.value as Language }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="en">{t(lang, 'langEnglish')}</option>
                    <option value="ps">{t(lang, 'langPashto')}</option>
                  </select>
                </label>

                <label className="space-y-1.5 text-sm">
                  <span className="text-[#CBD5E1] flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-[#D99B26]" />
                    <span>{t(lang, 'graphicsQuality')}</span>
                  </span>
                  <select
                    value={save.graphicsQuality}
                    onChange={(e) => setSave((s) => ({ ...s, graphicsQuality: e.target.value as GraphicsPreset }))}
                    className="w-full bg-[#0F1115] border border-white/15 rounded-lg px-3 py-2 text-sm text-white"
                  >
                    <option value="low">{t(lang, 'qualityLow')}</option>
                    <option value="medium">{t(lang, 'qualityMedium')}</option>
                    <option value="high">{t(lang, 'qualityHigh')}</option>
                  </select>
                </label>
              </div>

              <div className="space-y-4 pt-3 border-t border-white/10">
                <div className="text-xs font-semibold text-[#C2A878] flex items-center gap-2">
                  <Volume2 className="w-4 h-4" />
                  <span>Audio & Sensitivity</span>
                </div>

                {[
                  { key: 'musicVolume', label: t(lang, 'musicVolume'), min: 0, max: 1, step: 0.05 },
                  { key: 'sfxVolume', label: t(lang, 'sfxVolume'), min: 0, max: 1, step: 0.05 },
                  { key: 'envVolume', label: t(lang, 'envVolume'), min: 0, max: 1, step: 0.05 },
                  { key: 'cameraSensitivity', label: t(lang, 'camSens'), min: 0.4, max: 2.2, step: 0.05 },
                  { key: 'aimSensitivity', label: t(lang, 'aimSens'), min: 0.3, max: 1.6, step: 0.05 },
                  { key: 'controlSensitivity', label: t(lang, 'ctrlSens'), min: 0.5, max: 1.8, step: 0.05 },
                ].map((item) => {
                  const val = save[item.key as keyof SaveState] as number;
                  return (
                    <label key={item.key} className="block space-y-1">
                      <div className="flex justify-between text-xs text-[#CBD5E1]">
                        <span>{item.label}</span>
                        <span className="font-mono-num">{Math.round(val * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={item.min}
                        max={item.max}
                        step={item.step}
                        value={val}
                        onChange={(e) =>
                          setSave((s) => ({ ...s, [item.key]: Number(e.target.value) }))
                        }
                        className="w-full accent-[#D99B26]"
                      />
                    </label>
                  );
                })}
              </div>

              <div className="flex items-center justify-between gap-4 pt-2">
                <span className="text-xs text-[#6EE7B7]">{saveFeedback || ''}</span>
                <button
                  onClick={() => {
                    gameAudio.playUiClick();
                    setSaveFeedback(t(lang, 'savedBanner'));
                    setTimeout(() => setSaveFeedback(null), 2500);
                  }}
                  className="px-5 py-2.5 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-sm"
                >
                  {t(lang, 'saveSettings')}
                </button>
              </div>
            </div>
          </section>
        )}

        {screen === 'about' && (
          <section className="max-w-4xl w-full mx-auto px-6 py-10 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-3xl font-bold text-white">{t(lang, 'about')}</h1>
              <button onClick={() => setScreen('menu')} className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold">
                {t(lang, 'back')}
              </button>
            </div>

            <div className="bg-[#161A20] border border-white/10 rounded-xl p-6 space-y-5 text-sm text-[#D1D5DB] leading-relaxed">
              <p>{t(lang, 'aboutBody')}</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/10">
                <div>
                  <h3 className="font-semibold text-white mb-1">Fully Implemented</h3>
                  <p className="text-xs text-[#9CA3AF]">
                    Godot 4.3+ Mobile project (73 validated files), Missions 1–3, Free Battle, 3 maps, 5 firearms + frag grenades, Enemy AI, Jeep vehicle, Pashto RTL / English LTR, offline local saves, and playable Three.js arena.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-1">Modular Procedural Assets</h3>
                  <p className="text-xs text-[#9CA3AF]">
                    3D soldier, enemy, vehicle, and architecture meshes use multi-part modular procedural geometry (clearly marked as modular placeholders) paired with original generated .png textures and .wav audio.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-1">Android Device Testing</h3>
                  <p className="text-xs text-[#9CA3AF]">
                    APK export via Godot Export Templates (`export_presets.cfg`) and physical multi-touch / thermal profiling require testing on real Android hardware via `adb`.
                  </p>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      <ProjectExplorerModal open={explorerOpen} language={lang} onClose={() => setExplorerOpen(false)} />
    </div>
  );
}
