import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { gameAudio } from '../game/audio';
import { t, WEAPONS } from '../game/i18n';
import {
  createMilitaryJeep,
  createMudBrickCompound,
  createSoldierRig,
  createTree,
  createWatchtower,
  type SoldierRig,
} from '../game/models';
import { createMaterialLibrary } from '../game/textures';
import type {
  Difficulty,
  GraphicsPreset,
  HudSnapshot,
  Language,
  MapId,
  TimeOfDay,
  Weather,
} from '../game/types';

export interface MobileControlBridge {
  moveX: number;
  moveY: number;
  lookDeltaX: number;
  lookDeltaY: number;
  firing: boolean;
  aiming: boolean;
  sprinting: boolean;
  triggerJump: boolean;
  triggerCrouch: boolean;
  triggerReload: boolean;
  triggerSwitch: boolean;
  triggerGrenade: boolean;
  triggerInteract: boolean;
}

interface GameCanvasProps {
  mapId: MapId;
  difficulty: Difficulty;
  enemyCount: number;
  startingWeaponId: string;
  timeOfDay: TimeOfDay;
  weather: Weather;
  objectiveText: string;
  graphicsQuality: GraphicsPreset;
  cameraSensitivity: number;
  aimSensitivity: number;
  paused: boolean;
  language: Language;
  runKey: number;
  mobileBridgeRef: React.MutableRefObject<MobileControlBridge>;
  onHudUpdate: (hud: HudSnapshot) => void;
  onMissionEnd: (victory: boolean) => void;
  onRequestPause: () => void;
}

interface BoxCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
  mesh: THREE.Object3D;
}

interface EnemyActor {
  rig: SoldierRig;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  state: 'patrol' | 'alert' | 'engage' | 'reload' | 'retreat' | 'dead';
  mag: number;
  fireCd: number;
  reloadTimer: number;
  patrolPoints: THREE.Vector3[];
  patrolIdx: number;
  animPhase: number;
  hitRadius: number;
  deathTimer: number;
}

const _vecA = new THREE.Vector3();
const _vecB = new THREE.Vector3();
const _vecC = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();
const _rayDir = new THREE.Vector3();

export const GameCanvas: React.FC<GameCanvasProps> = ({
  mapId,
  difficulty,
  enemyCount,
  startingWeaponId,
  timeOfDay,
  weather,
  objectiveText,
  graphicsQuality,
  cameraSensitivity,
  aimSensitivity,
  paused,
  language,
  runKey,
  mobileBridgeRef,
  onHudUpdate,
  onMissionEnd,
  onRequestPause,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const pausedRef = useRef(paused);
  const sensRef = useRef({ cam: cameraSensitivity, aim: aimSensitivity });
  const langRef = useRef(language);
  const objTextRef = useRef(objectiveText);
  const callbacksRef = useRef({ onHudUpdate, onMissionEnd, onRequestPause });

  pausedRef.current = paused;
  sensRef.current = { cam: cameraSensitivity, aim: aimSensitivity };
  langRef.current = language;
  objTextRef.current = objectiveText;
  callbacksRef.current = { onHudUpdate, onMissionEnd, onRequestPause };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      try {
        const probe = document.createElement('canvas').getContext('webgl2');
        if (!probe) return true;
        const ext = probe.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
        const gpu = String(probe.getParameter(param));
        probe.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl && graphicsQuality !== 'low',
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    const dprCap =
      graphicsQuality === 'low' ? 0.85 : graphicsQuality === 'medium' ? 1.25 : Math.min(window.devicePixelRatio, 2);
    renderer.setPixelRatio(isSoftwareGl ? 1 : dprCap);
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => e.preventDefault();
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    const scene = new THREE.Scene();
    const skyColors: Record<TimeOfDay, number> = {
      day: weather === 'dust' ? 0xb59c74 : weather === 'rain' ? 0x5c6873 : 0x9bb7cc,
      dusk: 0xc28a5d,
      night: 0x101724,
    };
    const bgColor = skyColors[timeOfDay];
    scene.background = new THREE.Color(bgColor);
    const fogDensity = weather === 'dust' ? 0.014 : weather === 'rain' ? 0.013 : 0.0055;
    scene.fog = new THREE.FogExp2(bgColor, fogDensity);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(64, container.clientWidth / container.clientHeight, 0.1, 260);

    // Warm/Cool Outdoor Lighting Rig
    const hemiColor = timeOfDay === 'night' ? 0x3b4f78 : timeOfDay === 'dusk' ? 0xf2b07e : 0xcce0f5;
    const hemiGround = timeOfDay === 'night' ? 0x1a1c22 : 0x6b563c;
    const hemi = new THREE.HemisphereLight(hemiColor, hemiGround, timeOfDay === 'night' ? 0.45 : 0.72);
    scene.add(hemi);

    const sunColor = timeOfDay === 'night' ? 0x8ea9dc : timeOfDay === 'dusk' ? 0xffb26b : 0xfff1d6;
    const sunIntensity = timeOfDay === 'night' ? 0.55 : timeOfDay === 'dusk' ? 1.55 : 1.9;
    const sun = new THREE.DirectionalLight(sunColor, sunIntensity);
    sun.position.set(34, timeOfDay === 'dusk' ? 18 : 42, 26);
    sun.castShadow = !isSoftwareGl;
    const shadowSize = graphicsQuality === 'high' ? 2048 : graphicsQuality === 'medium' ? 1024 : 512;
    sun.shadow.mapSize.set(shadowSize, shadowSize);
    sun.shadow.camera.near = 2;
    sun.shadow.camera.far = 140;
    const sd = 48;
    sun.shadow.camera.left = -sd;
    sun.shadow.camera.right = sd;
    sun.shadow.camera.top = sd;
    sun.shadow.camera.bottom = -sd;
    sun.shadow.bias = -0.0005;
    sun.shadow.normalBias = 0.02;
    scene.add(sun);

    const mats = createMaterialLibrary(renderer.capabilities.getMaxAnisotropy());
    const colliders: BoxCollider[] = [];
    const obstacleMeshes: THREE.Object3D[] = [];

    const registerCollider = (mesh: THREE.Object3D, x: number, z: number, w: number, h: number, d: number) => {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        maxY: h,
        mesh,
      });
      obstacleMeshes.push(mesh);
    };

    // Extended Ground & Natural Mountain Ridge Perimeter
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(320, 320), mats.terrain);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Mountain perimeter ring
    const peakCount = 26;
    for (let i = 0; i < peakCount; i++) {
      const ang = (i / peakCount) * Math.PI * 2;
      const rad = 76 + (i % 3) * 14;
      const peakH = 18 + (i % 5) * 8;
      const peakW = 16 + (i % 4) * 5;
      const peak = new THREE.Mesh(new THREE.ConeGeometry(peakW, peakH, 6), mats.rock);
      peak.position.set(Math.cos(ang) * rad, peakH / 2 - 1, Math.sin(ang) * rad);
      peak.rotation.y = ang;
      peak.receiveShadow = true;
      scene.add(peak);
    }

    // Build selected map geometry
    if (mapId === 'village') {
      const compounds: [number, number, number, number, number][] = [
        [-14, -6, 8, 4.4, 8],
        [14, -10, 9, 4.8, 7.5],
        [-16, 12, 7.5, 4.2, 7.5],
        [15, 11, 8, 4.5, 8],
        [0, -24, 11, 5.2, 7],
      ];
      for (const [cx, cz, w, h, d] of compounds) {
        const comp = createMudBrickCompound(mats, w, h, d);
        comp.position.set(cx, 0, cz);
        scene.add(comp);
        registerCollider(comp, cx, cz, w, h, d);
      }

      // Checkpoint concrete barriers along central road
      const barriers: [number, number, number, number][] = [
        [-4.5, 6, 3.6, 0.9],
        [4.5, -2, 3.6, 0.9],
        [-3.5, -14, 3.6, 0.9],
      ];
      for (const [bx, bz, bw, bd] of barriers) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(bw, 1.25, bd), mats.concrete);
        bar.position.set(bx, 0.625, bz);
        bar.castShadow = true;
        bar.receiveShadow = true;
        scene.add(bar);
        registerCollider(bar, bx, bz, bw, 1.25, bd);
      }

      // Village olive trees
      const treeCoords: [number, number][] = [
        [-8, -16],
        [9, 4],
        [-22, 2],
        [22, -2],
        [6, 19],
      ];
      for (const [tx, tz] of treeCoords) {
        const tree = createTree(mats);
        tree.position.set(tx, 0, tz);
        scene.add(tree);
        registerCollider(tree, tx, tz, 1.1, 4.5, 1.1);
      }
    } else if (mapId === 'valley') {
      // River running through X=0
      const river = new THREE.Mesh(new THREE.PlaneGeometry(10, 180), mats.water);
      river.rotation.x = -Math.PI / 2;
      river.position.set(0, 0.03, 0);
      scene.add(river);

      // Wooden & Stone Bridge at Z=0
      const bridgeDeck = new THREE.Mesh(new THREE.BoxGeometry(12.5, 0.45, 5.6), mats.wood);
      bridgeDeck.position.set(0, 0.28, 0);
      bridgeDeck.receiveShadow = true;
      bridgeDeck.castShadow = true;
      scene.add(bridgeDeck);

      for (const side of [-2.6, 2.6]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(12.5, 0.7, 0.25), mats.wood);
        rail.position.set(0, 0.85, side);
        rail.castShadow = true;
        scene.add(rail);
      }

      // Valley boulders for tactical cover
      const rocks: [number, number, number][] = [
        [-12, 8, 2.4],
        [13, 6, 2.8],
        [-14, -12, 3.0],
        [12, -14, 2.6],
        [-9, -24, 3.2],
        [10, -24, 2.5],
      ];
      for (const [rx, rz, rs] of rocks) {
        const boulder = new THREE.Mesh(new THREE.DodecahedronGeometry(rs, 1), mats.rock);
        boulder.position.set(rx, rs * 0.55, rz);
        boulder.castShadow = true;
        boulder.receiveShadow = true;
        scene.add(boulder);
        registerCollider(boulder, rx, rz, rs * 1.5, rs * 1.4, rs * 1.5);
      }
    } else {
      // Military Outpost
      const towers: [number, number][] = [
        [-16, -16],
        [16, -16],
      ];
      for (const [tx, tz] of towers) {
        const tower = createWatchtower(mats);
        tower.position.set(tx, 0, tz);
        scene.add(tower);
        registerCollider(tower, tx, tz, 3.4, 6.5, 3.4);
      }

      const sheds: [number, number, number, number, number][] = [
        [-14, 4, 7, 3.6, 10],
        [14, 3, 7, 3.6, 10],
        [0, -22, 12, 4.2, 7],
      ];
      for (const [sx, sz, w, h, d] of sheds) {
        const shed = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mats.concrete);
        shed.position.set(sx, h / 2, sz);
        shed.castShadow = true;
        shed.receiveShadow = true;
        scene.add(shed);
        registerCollider(shed, sx, sz, w, h, d);
      }

      const perimeterWalls: [number, number, number, number][] = [
        [-6, 10, 4.8, 1.0],
        [6, 10, 4.8, 1.0],
        [-5, -8, 4.5, 1.0],
        [5, -8, 4.5, 1.0],
      ];
      for (const [wx, wz, ww, wd] of perimeterWalls) {
        const wall = new THREE.Mesh(new THREE.BoxGeometry(ww, 1.45, wd), mats.concrete);
        wall.position.set(wx, 0.725, wz);
        wall.castShadow = true;
        wall.receiveShadow = true;
        scene.add(wall);
        registerCollider(wall, wx, wz, ww, 1.45, wd);
      }
    }

    // Military Jeep (drivable in Village and Outpost)
    let jeepGroup: THREE.Group | null = null;
    if (mapId !== 'valley') {
      jeepGroup = createMilitaryJeep(mats);
      jeepGroup.position.set(-7.5, 0, 16);
      scene.add(jeepGroup);
    }

    // Ammo supply crates
    const ammoCrates: THREE.Mesh[] = [];
    const crateCoords: [number, number][] = [
      [7, 15],
      [-7, -10],
      [8, -18],
    ];
    for (const [ax, az] of crateCoords) {
      const crate = new THREE.Mesh(
        new THREE.BoxGeometry(0.95, 0.55, 0.65),
        new THREE.MeshStandardMaterial({ color: 0x4b5c34, roughness: 0.6, metalness: 0.2 })
      );
      crate.position.set(ax, 0.275, az);
      crate.castShadow = true;
      scene.add(crate);
      ammoCrates.push(crate);
    }

    // Weather particles (Rain or Dust)
    let weatherPoints: THREE.Points | null = null;
    if (weather !== 'clear' && graphicsQuality !== 'low') {
      const count = graphicsQuality === 'high' ? 600 : 300;
      const pos = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        pos[i * 3] = (Math.random() - 0.5) * 70;
        pos[i * 3 + 1] = Math.random() * 24;
        pos[i * 3 + 2] = (Math.random() - 0.5) * 70;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const pMat = new THREE.PointsMaterial({
        color: weather === 'rain' ? 0xb4c7d9 : 0xd6ba8b,
        size: weather === 'rain' ? 0.14 : 0.22,
        transparent: true,
        opacity: 0.65,
      });
      weatherPoints = new THREE.Points(geo, pMat);
      scene.add(weatherPoints);
    }

    // Player Rig
    const playerRig = createSoldierRig(mats, false);
    playerRig.group.position.set(0, 0, 22);
    scene.add(playerRig.group);

    // Muzzle flash light
    const muzzleFlash = new THREE.PointLight(0xffb44c, 0, 7);
    scene.add(muzzleFlash);

    // Pooled tracer lines & explosions
    const tracers: { mesh: THREE.Mesh; life: number }[] = [];
    const tracerGeo = new THREE.BoxGeometry(0.04, 0.04, 1.0);
    const tracerMat = new THREE.MeshBasicMaterial({ color: 0xffd269 });

    const grenades: { mesh: THREE.Mesh; vel: THREE.Vector3; fuse: number }[] = [];
    const grenadeGeo = new THREE.SphereGeometry(0.14, 10, 10);
    const grenadeMat = new THREE.MeshStandardMaterial({ color: 0x3b482e, roughness: 0.5, metalness: 0.4 });

    // Enemies
    const enemies: EnemyActor[] = [];
    const diffMult = difficulty === 'recruit' ? 0.75 : difficulty === 'elite' ? 1.35 : 1.0;
    for (let i = 0; i < enemyCount; i++) {
      const rig = createSoldierRig(mats, true);
      const ang = (i / Math.max(1, enemyCount)) * Math.PI * 2;
      const rad = 14 + (i % 3) * 6;
      const ex = Math.cos(ang) * rad;
      const ez = Math.sin(ang) * rad - 8;
      rig.group.position.set(ex, 0, ez);
      scene.add(rig.group);
      enemies.push({
        rig,
        hp: Math.round(80 * diffMult),
        maxHp: Math.round(80 * diffMult),
        speed: 3.4 * (difficulty === 'elite' ? 1.18 : 1.0),
        damage: Math.round(8 * diffMult),
        state: 'patrol',
        mag: 18,
        fireCd: 0.6 + Math.random() * 0.6,
        reloadTimer: 0,
        patrolPoints: [
          new THREE.Vector3(ex + 5, 0, ez),
          new THREE.Vector3(ex + 5, 0, ez + 6),
          new THREE.Vector3(ex - 5, 0, ez + 3),
        ],
        patrolIdx: 0,
        animPhase: Math.random() * 6.28,
        hitRadius: 0.65,
        deathTimer: 0,
      });
    }

    // Player State
    let playerHp = 100;
    let playerArmor = 50;
    let playerVelY = 0;
    let onGround = true;
    let isCrouching = false;
    let inVehicle = false;
    let jeepYaw = 0;
    let camYaw = 0;
    let camPitch = 0.24;
    let currentCamDist = 3.6;
    let recoilPitch = 0;
    let animPhase = 0;
    let stepTimer = 0;
    let gameOver = false;
    let statusBanner: string | null = null;
    let statusTimer = 0;

    // Weapons State
    let currentWeaponIdx = Math.max(
      0,
      WEAPONS.findIndex((w) => w.id === startingWeaponId)
    );
    const magAmmo: Record<string, number> = {};
    const reserveAmmo: Record<string, number> = {};
    WEAPONS.forEach((w) => {
      magAmmo[w.id] = w.magSize;
      reserveAmmo[w.id] = w.reserveMax;
    });
    let fireCooldown = 0;
    let isReloading = false;
    let reloadTimer = 0;
    let grenadesLeft = 3;

    // Input Tracking
    const keys: Record<string, boolean> = {};
    let mouseFiring = false;
    let mouseAiming = false;
    let draggingLook = false;

    const startReload = () => {
      const w = WEAPONS[currentWeaponIdx];
      if (isReloading || magAmmo[w.id] >= w.magSize || reserveAmmo[w.id] <= 0) return;
      isReloading = true;
      reloadTimer = w.reloadTime;
      gameAudio.playReload();
    };

    const switchWeapon = (nextIdx?: number) => {
      isReloading = false;
      currentWeaponIdx = nextIdx !== undefined ? nextIdx : (currentWeaponIdx + 1) % WEAPONS.length;
      gameAudio.playUiClick();
    };

    const throwGrenade = () => {
      if (grenadesLeft <= 0 || inVehicle) return;
      grenadesLeft--;
      const mesh = new THREE.Mesh(grenadeGeo, grenadeMat);
      mesh.position.copy(playerRig.group.position).add(new THREE.Vector3(0, 1.5, 0));
      scene.add(mesh);
      const dir = new THREE.Vector3(-Math.sin(camYaw), 0.35, -Math.cos(camYaw)).normalize();
      grenades.push({ mesh, vel: dir.multiplyScalar(15), fuse: 2.0 });
    };

    const tryInteract = () => {
      if (!jeepGroup) return;
      if (inVehicle) {
        inVehicle = false;
        playerRig.group.visible = true;
        playerRig.group.position.set(
          jeepGroup.position.x + Math.cos(jeepYaw) * 2.4,
          0,
          jeepGroup.position.z - Math.sin(jeepYaw) * 2.4
        );
      } else if (playerRig.group.position.distanceTo(jeepGroup.position) < 4.0) {
        inVehicle = true;
        playerRig.group.visible = false;
        gameAudio.playUiClick();
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;
      if (pausedRef.current || gameOver) return;
      if (e.code === 'KeyR') startReload();
      if (e.code === 'KeyQ') switchWeapon();
      if (e.code === 'KeyC') isCrouching = !isCrouching;
      if (e.code === 'KeyG') throwGrenade();
      if (e.code === 'KeyE') tryInteract();
      if (e.code === 'Escape') callbacksRef.current.onRequestPause();
      if (e.code >= 'Digit1' && e.code <= 'Digit5') {
        switchWeapon(Number(e.code.replace('Digit', '')) - 1);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    const onMouseDown = (e: MouseEvent) => {
      if (pausedRef.current || gameOver) return;
      if (e.button === 0) {
        if (document.pointerLockElement !== renderer.domElement && !isSoftwareGl) {
          renderer.domElement.requestPointerLock?.();
        }
        mouseFiring = true;
        draggingLook = true;
      } else if (e.button === 2) {
        mouseAiming = true;
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        mouseFiring = false;
        draggingLook = false;
      } else if (e.button === 2) {
        mouseAiming = false;
      }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (pausedRef.current || gameOver) return;
      if (document.pointerLockElement === renderer.domElement || draggingLook) {
        const s = (mouseAiming ? sensRef.current.aim : sensRef.current.cam) * 0.0028;
        camYaw -= e.movementX * s;
        camPitch = THREE.MathUtils.clamp(camPitch + e.movementY * s, -0.35, 1.05);
      }
    };

    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    renderer.domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('contextmenu', onContextMenu);

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    gameAudio.startAmbient(weather);

    const resolveHorizontalCollision = (pos: THREE.Vector3, radius: number) => {
      pos.x = THREE.MathUtils.clamp(pos.x, -58, 58);
      pos.z = THREE.MathUtils.clamp(pos.z, -58, 58);
      for (const c of colliders) {
        const closestX = THREE.MathUtils.clamp(pos.x, c.minX, c.maxX);
        const closestZ = THREE.MathUtils.clamp(pos.z, c.minZ, c.maxZ);
        const dx = pos.x - closestX;
        const dz = pos.z - closestZ;
        const distSq = dx * dx + dz * dz;
        if (distSq < radius * radius) {
          const dist = Math.sqrt(distSq) || 0.001;
          const push = radius - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        }
      }
    };

    const raycaster = new THREE.Raycaster();

    const spawnTracer = (from: THREE.Vector3, to: THREE.Vector3) => {
      const mesh = new THREE.Mesh(tracerGeo, tracerMat);
      const len = Math.max(0.5, Math.min(from.distanceTo(to), 18));
      mesh.scale.set(1, 1, len);
      mesh.position.copy(from).lerp(to, 0.5);
      mesh.lookAt(to);
      scene.add(mesh);
      tracers.push({ mesh, life: 0.065 });
    };

    const fireWeapon = (aiming: boolean) => {
      const w = WEAPONS[currentWeaponIdx];
      if (isReloading || fireCooldown > 0) return;
      if (magAmmo[w.id] <= 0) {
        startReload();
        return;
      }

      magAmmo[w.id]--;
      fireCooldown = w.fireRate;
      recoilPitch += w.recoil;
      gameAudio.playGunshot(w.id);

      playerRig.muzzlePoint.getWorldPosition(_vecA);
      muzzleFlash.position.copy(_vecA);
      muzzleFlash.intensity = 6;

      // Alert nearby enemies to gunshot sound
      for (const enemy of enemies) {
        if (enemy.state === 'patrol' && enemy.rig.group.position.distanceTo(playerRig.group.position) < 34) {
          enemy.state = 'alert';
        }
      }

      const spread = w.spread * (aiming ? 0.38 : 1.0);
      camera.getWorldPosition(_rayOrigin);
      camera.getWorldDirection(_rayDir);

      for (let p = 0; p < w.pellets; p++) {
        _vecB
          .copy(_rayDir)
          .add(
            _vecC.set(
              (Math.random() - 0.5) * spread,
              (Math.random() - 0.5) * spread,
              (Math.random() - 0.5) * spread
            )
          )
          .normalize();

        raycaster.set(_rayOrigin, _vecB);
        raycaster.far = w.range;

        const wallHits = raycaster.intersectObjects(obstacleMeshes, true);
        let maxDist = wallHits.length > 0 ? wallHits[0].distance : w.range;
        let hitEnemy: EnemyActor | null = null;

        for (const enemy of enemies) {
          if (enemy.state === 'dead') continue;
          const eCenter = _vecC.copy(enemy.rig.group.position).add(new THREE.Vector3(0, 1.05, 0));
          const toEnemy = eCenter.clone().sub(_rayOrigin);
          const proj = toEnemy.dot(_vecB);
          if (proj > 0 && proj < maxDist) {
            const closest = _rayOrigin.clone().addScaledVector(_vecB, proj);
            if (closest.distanceTo(eCenter) <= enemy.hitRadius) {
              maxDist = proj;
              hitEnemy = enemy;
            }
          }
        }

        const hitPoint = _rayOrigin.clone().addScaledVector(_vecB, maxDist);
        spawnTracer(_vecA, hitPoint);

        if (hitEnemy) {
          hitEnemy.hp -= w.damage;
          hitEnemy.state = 'engage';
          gameAudio.playHitMarker();
          if (hitEnemy.hp <= 0) {
            hitEnemy.state = 'dead';
            hitEnemy.deathTimer = 2.5;
          }
        }
      }

      if (!w.automatic) {
        mouseFiring = false;
      }
    };

    const damagePlayer = (dmg: number) => {
      if (gameOver) return;
      let rem = dmg;
      if (playerArmor > 0) {
        const absorb = Math.min(playerArmor, Math.ceil(rem * 0.6));
        playerArmor -= absorb;
        rem -= absorb;
      }
      playerHp = Math.max(0, playerHp - rem);
      if (playerHp <= 0) {
        gameOver = true;
        callbacksRef.current.onMissionEnd(false);
      }
    };

    const clock = new THREE.Clock();
    let frameId = 0;
    let hudTick = 0;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.08);
      const mb = mobileBridgeRef.current;

      if (!pausedRef.current && !gameOver) {
        // Consume one-shot mobile triggers
        if (mb.triggerJump) {
          mb.triggerJump = false;
          if (onGround && !inVehicle) {
            playerVelY = 6.2;
            onGround = false;
          }
        }
        if (mb.triggerCrouch) {
          mb.triggerCrouch = false;
          isCrouching = !isCrouching;
        }
        if (mb.triggerReload) {
          mb.triggerReload = false;
          startReload();
        }
        if (mb.triggerSwitch) {
          mb.triggerSwitch = false;
          switchWeapon();
        }
        if (mb.triggerGrenade) {
          mb.triggerGrenade = false;
          throwGrenade();
        }
        if (mb.triggerInteract) {
          mb.triggerInteract = false;
          tryInteract();
        }

        const aiming = mouseAiming || mb.aiming;
        if (mb.lookDeltaX !== 0 || mb.lookDeltaY !== 0) {
          const s = (aiming ? sensRef.current.aim : sensRef.current.cam) * 0.0045;
          camYaw -= mb.lookDeltaX * s;
          camPitch = THREE.MathUtils.clamp(camPitch + mb.lookDeltaY * s, -0.35, 1.05);
          mb.lookDeltaX = 0;
          mb.lookDeltaY = 0;
        }

        // Recoil settle
        if (recoilPitch > 0.001) {
          camPitch = THREE.MathUtils.clamp(camPitch - recoilPitch * dt * 2.2, -0.35, 1.05);
          recoilPitch = THREE.MathUtils.damp(recoilPitch, 0, 12, dt);
        }
        muzzleFlash.intensity = THREE.MathUtils.damp(muzzleFlash.intensity, 0, 22, dt);

        // Weapon timers
        if (fireCooldown > 0) fireCooldown -= dt;
        if (isReloading) {
          reloadTimer -= dt;
          if (reloadTimer <= 0) {
            const w = WEAPONS[currentWeaponIdx];
            const take = Math.min(w.magSize - magAmmo[w.id], reserveAmmo[w.id]);
            magAmmo[w.id] += take;
            reserveAmmo[w.id] -= take;
            isReloading = false;
          }
        }

        if ((mouseFiring || mb.firing) && !inVehicle) {
          fireWeapon(aiming);
        }

        // Movement
        const kbX = (keys['KeyD'] ? 1 : 0) - (keys['KeyA'] ? 1 : 0);
        const kbY = (keys['KeyS'] ? 1 : 0) - (keys['KeyW'] ? 1 : 0);
        const moveInX = Math.abs(mb.moveX) > 0.05 ? mb.moveX : kbX;
        const moveInY = Math.abs(mb.moveY) > 0.05 ? mb.moveY : kbY;

        if (inVehicle && jeepGroup) {
          const throttle = -moveInY;
          const steer = -moveInX;
          if (Math.abs(throttle) > 0.05) {
            jeepYaw += steer * 1.9 * dt * Math.sign(throttle);
          }
          jeepGroup.rotation.y = jeepYaw;
          jeepGroup.position.x += Math.sin(jeepYaw) * throttle * 13 * dt;
          jeepGroup.position.z += Math.cos(jeepYaw) * throttle * 13 * dt;
          resolveHorizontalCollision(jeepGroup.position, 1.8);
          playerRig.group.position.copy(jeepGroup.position);
        } else {
          const sprinting = (keys['ShiftLeft'] || mb.sprinting) && moveInY < -0.1 && !isCrouching;
          const speed = isCrouching ? 2.7 : sprinting ? 7.6 : 4.8;

          const fwdX = -Math.sin(camYaw);
          const fwdZ = -Math.cos(camYaw);
          const rightX = Math.cos(camYaw);
          const rightZ = -Math.sin(camYaw);

          let mx = rightX * moveInX - fwdX * moveInY;
          let mz = rightZ * moveInX - fwdZ * moveInY;
          const mLen = Math.hypot(mx, mz);
          if (mLen > 0.01) {
            mx /= Math.max(1, mLen);
            mz /= Math.max(1, mLen);
            playerRig.group.position.x += mx * speed * dt;
            playerRig.group.position.z += mz * speed * dt;
            resolveHorizontalCollision(playerRig.group.position, 0.48);

            animPhase += dt * (sprinting ? 13 : 8.5);
            playerRig.leftLeg.rotation.x = Math.sin(animPhase) * 0.55;
            playerRig.rightLeg.rotation.x = -Math.sin(animPhase) * 0.55;
            if (onGround) {
              stepTimer -= dt;
              if (stepTimer <= 0) {
                gameAudio.playFootstep();
                stepTimer = sprinting ? 0.28 : 0.44;
              }
            }
          } else {
            playerRig.leftLeg.rotation.x = THREE.MathUtils.damp(playerRig.leftLeg.rotation.x, 0, 10, dt);
            playerRig.rightLeg.rotation.x = THREE.MathUtils.damp(playerRig.rightLeg.rotation.x, 0, 10, dt);
          }

          if (keys['Space'] && onGround) {
            playerVelY = 6.2;
            onGround = false;
          }
          if (!onGround) {
            playerVelY -= 16 * dt;
            playerRig.group.position.y += playerVelY * dt;
            if (playerRig.group.position.y <= 0) {
              playerRig.group.position.y = 0;
              playerVelY = 0;
              onGround = true;
            }
          }

          const targetScaleY = isCrouching ? 0.72 : 1.0;
          playerRig.bodyPivot.scale.y = THREE.MathUtils.damp(playerRig.bodyPivot.scale.y, targetScaleY, 14, dt);
          playerRig.group.rotation.y = camYaw + Math.PI;
        }

        // Ammo Crate Pickups
        for (let i = ammoCrates.length - 1; i >= 0; i--) {
          const crate = ammoCrates[i];
          if (crate.visible && crate.position.distanceTo(playerRig.group.position) < 1.8) {
            crate.visible = false;
            const w = WEAPONS[currentWeaponIdx];
            reserveAmmo[w.id] = Math.min(w.reserveMax, reserveAmmo[w.id] + w.magSize);
            playerArmor = Math.min(50, playerArmor + 15);
            gameAudio.playReload();
          }
        }

        // Grenades
        for (let i = grenades.length - 1; i >= 0; i--) {
          const g = grenades[i];
          g.vel.y -= 15 * dt;
          g.mesh.position.addScaledVector(g.vel, dt);
          if (g.mesh.position.y < 0.14) {
            g.mesh.position.y = 0.14;
            g.vel.y *= -0.35;
            g.vel.x *= 0.7;
            g.vel.z *= 0.7;
          }
          g.fuse -= dt;
          if (g.fuse <= 0) {
            gameAudio.playExplosion();
            for (const enemy of enemies) {
              if (enemy.state === 'dead') continue;
              const dist = enemy.rig.group.position.distanceTo(g.mesh.position);
              if (dist < 8.5) {
                enemy.hp -= Math.round(125 * (1 - dist / 8.5));
                if (enemy.hp <= 0) {
                  enemy.state = 'dead';
                  enemy.deathTimer = 2.5;
                }
              }
            }
            scene.remove(g.mesh);
            grenades.splice(i, 1);
          }
        }

        // Enemy AI
        let aliveCount = 0;
        for (const enemy of enemies) {
          if (enemy.state === 'dead') {
            enemy.rig.bodyPivot.rotation.x = THREE.MathUtils.damp(enemy.rig.bodyPivot.rotation.x, Math.PI / 2, 8, dt);
            enemy.deathTimer -= dt;
            if (enemy.deathTimer <= 0) {
              enemy.rig.group.visible = false;
            }
            continue;
          }
          aliveCount++;
          const dist = enemy.rig.group.position.distanceTo(playerRig.group.position);
          const canSee = dist < 29;
          if (enemy.state === 'patrol' && canSee) {
            enemy.state = 'engage';
          }

          if (enemy.state === 'patrol' || enemy.state === 'alert') {
            const target = enemy.state === 'alert' ? playerRig.group.position : enemy.patrolPoints[enemy.patrolIdx];
            const toTarget = _vecA.copy(target).sub(enemy.rig.group.position);
            toTarget.y = 0;
            if (toTarget.length() < 1.3 && enemy.state === 'patrol') {
              enemy.patrolIdx = (enemy.patrolIdx + 1) % enemy.patrolPoints.length;
            } else if (toTarget.length() > 0.2) {
              toTarget.normalize();
              enemy.rig.group.position.addScaledVector(toTarget, enemy.speed * 0.65 * dt);
              resolveHorizontalCollision(enemy.rig.group.position, 0.5);
              enemy.rig.group.rotation.y = Math.atan2(toTarget.x, toTarget.z);
              enemy.animPhase += dt * 7;
              enemy.rig.leftLeg.rotation.x = Math.sin(enemy.animPhase) * 0.45;
              enemy.rig.rightLeg.rotation.x = -Math.sin(enemy.animPhase) * 0.45;
            }
            if (canSee) enemy.state = 'engage';
          } else if (enemy.state === 'reload') {
            enemy.reloadTimer -= dt;
            if (enemy.reloadTimer <= 0) {
              enemy.mag = 18;
              enemy.state = 'engage';
            }
          } else if (enemy.state === 'engage' || enemy.state === 'retreat') {
            if (enemy.hp < enemy.maxHp * 0.25) enemy.state = 'retreat';
            const toPlayer = _vecA.copy(playerRig.group.position).sub(enemy.rig.group.position);
            toPlayer.y = 0;
            const dLen = toPlayer.length() || 1;
            toPlayer.divideScalar(dLen);
            enemy.rig.group.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);

            if (enemy.state === 'retreat') {
              enemy.rig.group.position.addScaledVector(toPlayer, -enemy.speed * dt);
              resolveHorizontalCollision(enemy.rig.group.position, 0.5);
            } else if (dist > 14) {
              enemy.rig.group.position.addScaledVector(toPlayer, enemy.speed * dt);
              resolveHorizontalCollision(enemy.rig.group.position, 0.5);
              enemy.animPhase += dt * 8.5;
              enemy.rig.leftLeg.rotation.x = Math.sin(enemy.animPhase) * 0.5;
              enemy.rig.rightLeg.rotation.x = -Math.sin(enemy.animPhase) * 0.5;
            } else {
              enemy.rig.leftLeg.rotation.x = 0;
              enemy.rig.rightLeg.rotation.x = 0;
            }

            if (enemy.mag <= 0) {
              enemy.state = 'reload';
              enemy.reloadTimer = 1.8;
            } else {
              enemy.fireCd -= dt;
              if (enemy.fireCd <= 0 && dist < 27) {
                enemy.fireCd = 0.55 + Math.random() * 0.55;
                enemy.mag--;
                gameAudio.playGunshot('khyber_47');
                enemy.rig.muzzlePoint.getWorldPosition(_vecB);
                const aimTarget = playerRig.group.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 1.4, 1.1, (Math.random() - 0.5) * 1.4));
                spawnTracer(_vecB, aimTarget);
                if (Math.random() < (difficulty === 'recruit' ? 0.25 : difficulty === 'elite' ? 0.52 : 0.36)) {
                  damagePlayer(enemy.damage);
                }
              }
            }
          }
        }

        if (aliveCount === 0 && !gameOver) {
          gameOver = true;
          callbacksRef.current.onMissionEnd(true);
        }

        // Tracers decay
        for (let i = tracers.length - 1; i >= 0; i--) {
          tracers[i].life -= dt;
          if (tracers[i].life <= 0) {
            scene.remove(tracers[i].mesh);
            tracers.splice(i, 1);
          }
        }

        // Weather animate
        if (weatherPoints) {
          const arr = weatherPoints.geometry.attributes.position.array as Float32Array;
          for (let i = 0; i < arr.length; i += 3) {
            if (weather === 'rain') {
              arr[i + 1] -= 18 * dt;
              if (arr[i + 1] < 0) arr[i + 1] = 24;
            } else {
              arr[i] += 5.5 * dt;
              if (arr[i] > 35) arr[i] = -35;
            }
          }
          weatherPoints.geometry.attributes.position.needsUpdate = true;
        }

        // Camera smooth third-person follow + collision clamping
        const w = WEAPONS[currentWeaponIdx];
        const targetFov = aiming ? w.zoomFov : 64;
        if (Math.abs(camera.fov - targetFov) > 0.1) {
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 12, dt);
          camera.updateProjectionMatrix();
        }
        const desiredDist = inVehicle ? 6.2 : aiming ? 1.85 : 3.6;
        currentCamDist = THREE.MathUtils.damp(currentCamDist, desiredDist, 12, dt);

        const pivotY = inVehicle ? 1.9 : isCrouching ? 1.15 : 1.55;
        const shoulderRight = inVehicle ? 0 : aiming ? 0.65 : 0.5;
        const focus = _vecA.set(
          playerRig.group.position.x + Math.cos(camYaw) * shoulderRight,
          playerRig.group.position.y + pivotY,
          playerRig.group.position.z - Math.sin(camYaw) * shoulderRight
        );

        const camBack = _vecB.set(
          Math.sin(camYaw) * Math.cos(camPitch),
          Math.sin(camPitch),
          Math.cos(camYaw) * Math.cos(camPitch)
        );
        raycaster.set(focus, camBack);
        raycaster.far = currentCamDist;
        const camWalls = raycaster.intersectObjects(obstacleMeshes, true);
        const safeDist = camWalls.length > 0 ? Math.max(0.75, camWalls[0].distance - 0.25) : currentCamDist;

        const targetCamPos = _vecC.copy(focus).addScaledVector(camBack, safeDist);
        targetCamPos.y = Math.max(0.45, targetCamPos.y);
        camera.position.lerp(targetCamPos, 1 - Math.exp(-18 * dt));
        camera.lookAt(focus.x - Math.sin(camYaw) * 8, focus.y - Math.sin(camPitch) * 6, focus.z - Math.cos(camYaw) * 8);

        // Periodic HUD snapshot
        hudTick += dt;
        if (hudTick >= 0.08) {
          hudTick = 0;
          const nearbyVehicle = !inVehicle && jeepGroup !== null && playerRig.group.position.distanceTo(jeepGroup.position) < 4.0;
          if (statusTimer > 0) {
            statusTimer -= 0.08;
            if (statusTimer <= 0) statusBanner = null;
          }
          callbacksRef.current.onHudUpdate({
            health: playerHp,
            maxHealth: 100,
            armor: playerArmor,
            maxArmor: 50,
            magAmmo: magAmmo[w.id],
            reserveAmmo: reserveAmmo[w.id],
            weaponId: w.id,
            weaponName: langRef.current === 'ps' ? w.namePs : w.nameEn,
            grenades: grenadesLeft,
            isReloading,
            isAiming: aiming,
            isCrouching,
            inVehicle,
            nearbyVehicle,
            enemiesRemaining: aliveCount,
            enemiesTotal: enemyCount,
            objectiveText: objTextRef.current,
            statusBanner: inVehicle
              ? t(langRef.current, 'exitVehicle')
              : nearbyVehicle
                ? t(langRef.current, 'enterVehicle')
                : statusBanner,
          });
        }
      }

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    };

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      gameAudio.stopAmbient();
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      renderer.domElement.removeEventListener('contextmenu', onContextMenu);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      mats.dispose();
      tracerGeo.dispose();
      tracerMat.dispose();
      grenadeGeo.dispose();
      grenadeMat.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [mapId, difficulty, enemyCount, startingWeaponId, timeOfDay, weather, graphicsQuality, runKey]);

  return <div ref={mountRef} className="w-full h-full select-none touch-none" />;
};
