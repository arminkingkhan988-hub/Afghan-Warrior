import React, { useRef, useState } from 'react';
import type { Language } from '../game/types';
import { t } from '../game/i18n';
import type { MobileControlBridge } from './GameCanvas';

interface MobileControlsOverlayProps {
  bridgeRef: React.MutableRefObject<MobileControlBridge>;
  language: Language;
  controlSensitivity: number;
  visible: boolean;
  nearbyVehicle: boolean;
  inVehicle: boolean;
  isAiming: boolean;
  isCrouching: boolean;
  onPause: () => void;
}

export const MobileControlsOverlay: React.FC<MobileControlsOverlayProps> = ({
  bridgeRef,
  language,
  controlSensitivity,
  visible,
  nearbyVehicle,
  inVehicle,
  isAiming,
  isCrouching,
  onPause,
}) => {
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const joyPointerId = useRef<number | null>(null);
  const joyOrigin = useRef({ x: 0, y: 0 });
  const lookPointerId = useRef<number | null>(null);
  const lookPrev = useRef({ x: 0, y: 0 });

  if (!visible) return null;

  const maxRadius = 44;

  const onJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    joyPointerId.current = e.pointerId;
    const rect = e.currentTarget.getBoundingClientRect();
    joyOrigin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  };

  const onJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    const dx = e.clientX - joyOrigin.current.x;
    const dy = e.clientY - joyOrigin.current.y;
    const len = Math.hypot(dx, dy);
    const clamped = Math.min(len, maxRadius);
    const nx = len > 0 ? (dx / len) * clamped : 0;
    const ny = len > 0 ? (dy / len) * clamped : 0;
    setKnobOffset({ x: nx, y: ny });
    bridgeRef.current.moveX = (nx / maxRadius) * controlSensitivity;
    bridgeRef.current.moveY = (ny / maxRadius) * controlSensitivity;
  };

  const onJoyUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    joyPointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    bridgeRef.current.moveX = 0;
    bridgeRef.current.moveY = 0;
  };

  const onLookDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    lookPointerId.current = e.pointerId;
    lookPrev.current = { x: e.clientX, y: e.clientY };
  };

  const onLookMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    const dx = e.clientX - lookPrev.current.x;
    const dy = e.clientY - lookPrev.current.y;
    lookPrev.current = { x: e.clientX, y: e.clientY };
    bridgeRef.current.lookDeltaX += dx * 1.4;
    bridgeRef.current.lookDeltaY += dy * 1.4;
  };

  const onLookUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current === e.pointerId) {
      lookPointerId.current = null;
    }
  };

  return (
    <div className="fixed inset-0 z-20 pointer-events-none select-none" dir="ltr">
      {/* Right-half touch camera drag surface */}
      <div
        className="absolute top-16 right-0 bottom-0 left-[42%] pointer-events-auto touch-none"
        onPointerDown={onLookDown}
        onPointerMove={onLookMove}
        onPointerUp={onLookUp}
        onPointerCancel={onLookUp}
      />

      {/* Left virtual movement joystick */}
      <div
        onPointerDown={onJoyDown}
        onPointerMove={onJoyMove}
        onPointerUp={onJoyUp}
        onPointerCancel={onJoyUp}
        className="absolute bottom-7 left-7 w-32 h-32 rounded-full bg-[#11151C]/70 border border-white/25 flex items-center justify-center pointer-events-auto touch-none"
      >
        <div
          className="w-14 h-14 rounded-full bg-[#D99B26]/85 border-2 border-white/60 shadow-lg"
          style={{ transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)` }}
        />
      </div>

      {/* Sprint button above joystick */}
      <button
        type="button"
        onPointerDown={(e) => {
          e.stopPropagation();
          bridgeRef.current.sprinting = true;
        }}
        onPointerUp={() => {
          bridgeRef.current.sprinting = false;
        }}
        onPointerCancel={() => {
          bridgeRef.current.sprinting = false;
        }}
        className="absolute bottom-44 left-12 w-14 h-11 rounded-lg bg-[#161B22]/85 border border-white/25 text-[11px] font-semibold text-white pointer-events-auto active:bg-[#D99B26] active:text-black"
      >
        {t(language, 'sprintBtn')}
      </button>

      {/* Right side action cluster */}
      <div className="absolute bottom-6 right-6 flex flex-col items-end gap-3 pointer-events-auto">
        <div className="flex items-center gap-2.5">
          {(nearbyVehicle || inVehicle) && (
            <button
              type="button"
              onClick={() => {
                bridgeRef.current.triggerInteract = true;
              }}
              className="px-3.5 h-11 rounded-lg bg-[#D99B26] text-[#0F1115] text-xs font-bold border border-white/30"
            >
              {t(language, 'interactBtn')}
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.triggerGrenade = true;
            }}
            className="w-12 h-11 rounded-lg bg-[#161B22]/85 border border-white/25 text-[11px] font-semibold text-white active:bg-white/20"
          >
            {t(language, 'grenadeBtn')}
          </button>
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.triggerSwitch = true;
            }}
            className="w-12 h-11 rounded-lg bg-[#161B22]/85 border border-white/25 text-[11px] font-semibold text-white active:bg-white/20"
          >
            {t(language, 'switchBtn')}
          </button>
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.triggerCrouch = true;
            }}
            className={`w-12 h-11 rounded-lg border text-[11px] font-semibold ${
              isCrouching ? 'bg-[#D99B26] text-black border-white/40' : 'bg-[#161B22]/85 text-white border-white/25'
            }`}
          >
            {t(language, 'crouchBtn')}
          </button>
        </div>

        <div className="flex items-end gap-3">
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.triggerReload = true;
            }}
            className="w-13 h-12 rounded-lg bg-[#161B22]/85 border border-white/25 text-[11px] font-semibold text-white active:bg-white/20"
          >
            {t(language, 'reloadBtn')}
          </button>
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.triggerJump = true;
            }}
            className="w-13 h-12 rounded-lg bg-[#161B22]/85 border border-white/25 text-[11px] font-semibold text-white active:bg-white/20"
          >
            {t(language, 'jumpBtn')}
          </button>
          <button
            type="button"
            onClick={() => {
              bridgeRef.current.aiming = !bridgeRef.current.aiming;
            }}
            className={`w-14 h-14 rounded-full border text-xs font-bold ${
              isAiming ? 'bg-[#D99B26] text-[#0F1115] border-white/60' : 'bg-[#161B22]/85 text-white border-white/30'
            }`}
          >
            {t(language, 'aimBtn')}
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              bridgeRef.current.firing = true;
            }}
            onPointerUp={() => {
              bridgeRef.current.firing = false;
            }}
            onPointerCancel={() => {
              bridgeRef.current.firing = false;
            }}
            className="w-20 h-20 rounded-full bg-[#C93B2B]/90 active:bg-[#E04B3A] border-2 border-white/50 text-sm font-bold text-white shadow-lg"
          >
            {t(language, 'fireBtn')}
          </button>
        </div>
      </div>

      {/* Top right pause shortcut */}
      <button
        type="button"
        onClick={onPause}
        className="absolute top-4 right-4 px-3.5 py-2 rounded-lg bg-[#161B22]/85 border border-white/25 text-xs font-semibold text-white pointer-events-auto"
      >
        {t(language, 'pauseBtn')}
      </button>
    </div>
  );
};
