import React, { useEffect, useState } from 'react';
import { Download, FileCode2, FolderOpen, X } from 'lucide-react';
import type { Language } from '../game/types';
import { t } from '../game/i18n';

interface ManifestFile {
  path: string;
  size: number;
  preview: string;
}

interface ProjectExplorerModalProps {
  open: boolean;
  language: Language;
  onClose: () => void;
}

export const ProjectExplorerModal: React.FC<ProjectExplorerModalProps> = ({ open, language, onClose }) => {
  const [files, setFiles] = useState<ManifestFile[]>([]);
  const [selected, setSelected] = useState<ManifestFile | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || files.length > 0) return;
    setLoading(true);
    fetch('/godot_manifest.json')
      .then((res) => res.json())
      .then((data: { files: ManifestFile[] }) => {
        setFiles(data.files || []);
        const readme = data.files?.find((f) => f.path.endsWith('README.md'));
        setSelected(readme || data.files?.[0] || null);
      })
      .catch(() => setFiles([]))
      .finally(() => setLoading(false));
  }, [open, files.length]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      dir={language === 'ps' ? 'rtl' : 'ltr'}
    >
      <div className="w-full max-w-6xl h-[86vh] bg-[#161A20] border border-white/15 rounded-xl flex flex-col overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-white/10">
          <div>
            <h2 className="font-display text-xl font-semibold tracking-wide text-[#F1F3F5]">
              {language === 'ps' ? 'د Godot 4 انډرایډ پروژه او ZIP فایل' : 'Godot 4.x Android Project Package'}
            </h2>
            <p className="text-xs text-[#9CA3AF] mt-0.5">
              {files.length} {language === 'ps' ? 'تایید شوي فایلونه · آفلاین انډرایډ APK جوړښت' : 'validated project files · Offline Android APK ready'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="/Afghan_Warrior_Complete_Project.zip"
              download="Afghan_Warrior_Complete_Project.zip"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D99B26] hover:bg-[#E5A935] text-[#0F1115] font-semibold text-xs whitespace-nowrap transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>{t(language, 'downloadZip')}</span>
            </a>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-[#D1D5DB] transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 min-h-0">
          <div className="md:col-span-4 border-b md:border-b-0 md:border-e border-white/10 overflow-y-auto p-3 bg-[#12151A]">
            {loading ? (
              <div className="text-xs text-[#9CA3AF] p-4">Loading project tree...</div>
            ) : (
              <div className="space-y-1">
                {files.map((f) => {
                  const active = selected?.path === f.path;
                  return (
                    <button
                      key={f.path}
                      onClick={() => setSelected(f)}
                      className={`w-full text-start px-3 py-1.5 rounded-md text-xs flex items-center justify-between gap-2 transition-colors ${
                        active ? 'bg-[#D99B26]/20 text-[#F4C462]' : 'text-[#CBD5E1] hover:bg-white/5'
                      }`}
                    >
                      <span className="truncate flex items-center gap-2">
                        {f.preview ? <FileCode2 className="w-3.5 h-3.5 shrink-0" /> : <FolderOpen className="w-3.5 h-3.5 shrink-0" />}
                        <span className="truncate">{f.path}</span>
                      </span>
                      <span className="font-mono-num text-[11px] text-[#9CA3AF] shrink-0">
                        {f.size > 1024 ? `${(f.size / 1024).toFixed(1)}KB` : `${f.size}B`}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="md:col-span-8 overflow-auto p-5 bg-[#0F1115]" dir="ltr">
            {selected ? (
              <div>
                <div className="text-xs font-mono-num text-[#D99B26] pb-3 mb-3 border-b border-white/10 flex items-center justify-between">
                  <span>{selected.path}</span>
                  <span>{selected.size} bytes</span>
                </div>
                {selected.preview ? (
                  <pre className="text-xs font-mono-num text-[#E2E8F0] whitespace-pre-wrap leading-relaxed">
                    {selected.preview}
                  </pre>
                ) : (
                  <div className="text-sm text-[#9CA3AF]">
                    Binary procedural asset ({selected.path.split('.').pop()?.toUpperCase()}) included inside Afghan_Warrior_Complete_Project.zip.
                  </div>
                )}
              </div>
            ) : (
              <div className="text-sm text-[#9CA3AF]">Select a file from the Godot 4 project tree to inspect.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
